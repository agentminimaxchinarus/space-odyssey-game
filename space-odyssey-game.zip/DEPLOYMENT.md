# Инструкция по развертыванию Space Odyssey в Telegram

## Шаг 1: Подготовка файлов

Все файлы проекта готовы:
- `index.html` - главная страница игры
- `game.js` - игровой движок
- `telegram-integration.js` - интеграция с Telegram
- `server.py` - backend сервер (опционально)

## Шаг 2: Выбор хостинга

### Вариант A: Vercel (Рекомендуется - бесплатно)

1. Зарегистрируйтесь на [vercel.com](https://vercel.com)
2. Установите Vercel CLI:
```bash
npm i -g vercel
```
3. В папке с проектом выполните:
```bash
vercel
```
4. Следуйте инструкциям на экране
5. Получите URL типа `https://your-project.vercel.app`

### Вариант B: Netlify (Альтернатива)

1. Зарегистрируйтесь на [netlify.com](https://netlify.com)
2. Перетащите папку с проектом в Netlify Drop
3. Получите URL типа `https://your-project.netlify.app`

### Вариант C: GitHub Pages (Для простоты)

1. Создайте репозиторий на GitHub
2. Загрузите файлы проекта
3. В Settings → Pages включите GitHub Pages
4. Получите URL типа `https://username.github.io/space-odyssey`

## Шаг 3: Создание Telegram бота

1. Откройте [@BotFather](https://t.me/BotFather) в Telegram
2. Отправьте команду `/newbot`
3. Введите имя бота (например: "Space Odyssey Game")
4. Введите username бота (например: "SpaceOdysseyGameBot")
5. Сохраните токен бота (понадобится позже)

## Шаг 4: Создание Web App

1. В чате с @BotFather отправьте `/newapp`
2. Выберите вашего бота
3. Заполните информацию:
   - **Название:** Space Odyssey
   - **Описание:** Полноценная 3D космическая RPG игра
   - **Фото:** Загрузите иконку 640x360 пикселей
   - **GIF/Видео:** (Опционально) Демонстрация игры
   - **URL:** Ваш URL с хостинга (например: https://your-project.vercel.app)
   - **Short name:** space_odyssey

4. Получите ссылку типа: `https://t.me/YourBot/space_odyssey`

## Шаг 5: Настройка Backend (Опционально)

Если вы хотите сохранение прогресса и лидерборды:

### На Render.com (Бесплатно):

1. Зарегистрируйтесь на [render.com](https://render.com)
2. Создайте новый **Web Service**
3. Подключите GitHub репозиторий
4. Настройки:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn server:app --host 0.0.0.0 --port $PORT`
   - **Environment:** Python 3.11
5. Получите URL API: `https://your-service.onrender.com`

### Обновите game.js:

В начале файла `telegram-integration.js` замените:
```javascript
const API_URL = 'https://your-service.onrender.com';

// В функциях замените '/api/' на `${API_URL}/api/`
```

## Шаг 6: Настройка Telegram Stars (Монетизация)

### Включение платежей:

1. В @BotFather отправьте `/mybots`
2. Выберите вашего бота
3. Нажмите "Payments"
4. Выберите "Telegram Stars" как провайдера
5. Подтвердите

### Создание инвойсов через Bot API:

Вам понадобится создать endpoint на backend для генерации инвойсов:

```python
# В server.py добавьте:

import requests

BOT_TOKEN = "YOUR_BOT_TOKEN"  # Токен от @BotFather

@app.post("/api/create-invoice")
async def create_invoice(invoice_data: dict):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/createInvoiceLink"
    
    payload = {
        "title": invoice_data["title"],
        "description": invoice_data["description"],
        "payload": invoice_data["payload"],
        "provider_token": "",  # Пусто для Telegram Stars
        "currency": "XTR",
        "prices": invoice_data["prices"]
    }
    
    response = requests.post(url, json=payload)
    data = response.json()
    
    return {"invoice_link": data["result"]}
```

## Шаг 7: Тестирование

1. Откройте вашего бота в Telegram
2. Нажмите "Start" или используйте команду `/start`
3. Откройте Web App через кнопку или ссылку
4. Проверьте все функции:
   - ✅ Запуск игры
   - ✅ Управление кораблем
   - ✅ Стрельба по врагам
   - ✅ Система улучшений
   - ✅ Сохранение прогресса (если backend включен)
   - ✅ Лидерборды
   - ✅ Покупки через Telegram Stars

## Шаг 8: Публикация

### Отправка на проверку (для публичного бота):

1. В @BotFather: `/setdescription` - добавьте описание
2. `/setabouttext` - краткое описание
3. `/setuserpic` - загрузите аватар бота
4. `/setcommands` - настройте команды:
```
start - Начать игру
help - Помощь
stats - Статистика
leaderboard - Топ игроков
```

### Продвижение:

1. Поделитесь ботом в Telegram каналах
2. Используйте встроенный режим Telegram:
```python
# Для inline режима в @BotFather
/setinline
# Включите inline режим
```

## Дополнительные настройки

### Для production:

1. **Включите HTTPS** (обязательно для Telegram)
2. **Добавьте rate limiting** в API
3. **Настройте мониторинг** (UptimeRobot, Datadog)
4. **Включите логирование** ошибок
5. **Оптимизируйте 3D ресурсы** (сжатие текстур)

### Оптимизация производительности:

В `game.js` настройте под мобильные устройства:
```javascript
// Уменьшите количество звезд на мобильных
const isMobile = /iPhone|iPad|Android/i.test(navigator.userAgent);
const starCount = isMobile ? 1000 : 2000;

// Настройте качество рендеринга
renderer.setPixelRatio(isMobile ? 1 : window.devicePixelRatio);
```

### Аналитика:

Добавьте Telegram Analytics:
```javascript
// В telegram-integration.js
tg.sendData(JSON.stringify({
    event: 'game_start',
    user_id: this.userId,
    timestamp: Date.now()
}));
```

## Решение проблем

### Игра не загружается:

1. Проверьте URL в настройках Web App
2. Убедитесь что используется HTTPS
3. Проверьте консоль браузера на ошибки
4. Очистите кеш Telegram

### Backend не работает:

1. Проверьте логи на хостинге
2. Убедитесь что порт правильный
3. Проверьте CORS настройки
4. Убедитесь что `requirements.txt` установлен

### Платежи не работают:

1. Проверьте что Telegram Stars включены в @BotFather
2. Убедитесь что инвойсы создаются правильно
3. Проверьте токен бота
4. Тестируйте с реальными Telegram Stars

## Поддержка

Если возникли проблемы:
1. Проверьте документацию Telegram: https://core.telegram.org/bots/webapps
2. Проверьте логи сервера
3. Используйте Telegram Web App Debug Mode

## Готово! 🎉

Ваша игра готова к запуску в Telegram!

Не забудьте:
- 📱 Протестировать на разных устройствах
- 🎮 Проверить все игровые механики
- 💰 Настроить систему монетизации
- 📊 Настроить аналитику
- 🚀 Поделиться с друзьями!

Удачи с вашей космической RPG! 🚀✨
