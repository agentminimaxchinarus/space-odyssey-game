// ================================
// SPACE ODYSSEY - 3D Space RPG Game
// Full-featured game with monetization
// ================================

// Initialize Telegram WebApp
let tg = window.Telegram?.WebApp;
if (tg) {
    tg.ready();
    tg.expand();
}

// ================================
// GAME STATE
// ================================
const GameState = {
    // Player stats
    player: {
        health: 100,
        maxHealth: 100,
        energy: 100,
        maxEnergy: 100,
        level: 1,
        exp: 0,
        expToLevel: 100,
        credits: 0,
        score: 0,
        kills: 0,
        
        // Ship stats
        damage: 10,
        fireRate: 250,
        speed: 0.5,
        defense: 1,
        specialCooldown: 5000,
        
        // Upgrades
        upgrades: {
            weaponLevel: 1,
            shieldLevel: 1,
            engineLevel: 1,
            energyLevel: 1,
            specialLevel: 1
        }
    },
    
    // Game settings
    settings: {
        difficulty: 1,
        waveNumber: 1,
        enemiesPerWave: 5,
        bossEvery: 5
    },
    
    // Missions
    missions: [
        { id: 1, title: "Первый контакт", desc: "Уничтожь 10 врагов", target: 10, reward: 500, completed: false },
        { id: 2, title: "Коллекционер", desc: "Собери 1000 кредитов", target: 1000, reward: 1000, completed: false },
        { id: 3, title: "Выживший", desc: "Достигни 5 уровня", target: 5, reward: 2000, completed: false },
        { id: 4, title: "Охотник на боссов", desc: "Победи первого босса", target: 1, reward: 3000, completed: false },
        { id: 5, title: "Мастер космоса", desc: "Набери 10000 очков", target: 10000, reward: 5000, completed: false }
    ],
    
    // Runtime state
    isRunning: false,
    isPaused: false,
    lastFireTime: 0,
    lastSpecialTime: 0,
    enemySpawnTimer: 0,
    energyRegenTimer: 0
};

// ================================
// THREE.JS SETUP
// ================================
let scene, camera, renderer, clock;
let player, enemies = [], bullets = [], particles = [], powerups = [];
let stars = [];
let joystickActive = false;
let joystickVector = { x: 0, y: 0 };

function initThreeJS() {
    // Scene
    scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x000000, 0.001);
    
    // Camera
    const aspect = window.innerWidth / window.innerHeight;
    camera = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000);
    camera.position.set(0, 30, 50);
    camera.lookAt(0, 0, 0);
    
    // Renderer
    const canvas = document.getElementById('gameCanvas');
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    
    // Clock
    clock = new THREE.Clock();
    
    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.5);
    scene.add(ambientLight);
    
    const pointLight1 = new THREE.PointLight(0x00ffff, 1, 100);
    pointLight1.position.set(0, 20, 20);
    scene.add(pointLight1);
    
    const pointLight2 = new THREE.PointLight(0xff00ff, 0.5, 100);
    pointLight2.position.set(-20, 10, -20);
    scene.add(pointLight2);
    
    // Create starfield
    createStarfield();
    
    // Create player ship
    createPlayerShip();
    
    // Window resize handler
    window.addEventListener('resize', onWindowResize);
}

function createStarfield() {
    const starGeometry = new THREE.BufferGeometry();
    const starVertices = [];
    
    for (let i = 0; i < 2000; i++) {
        const x = (Math.random() - 0.5) * 2000;
        const y = (Math.random() - 0.5) * 2000;
        const z = (Math.random() - 0.5) * 2000;
        starVertices.push(x, y, z);
    }
    
    starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starVertices, 3));
    
    const starMaterial = new THREE.PointsMaterial({
        color: 0xffffff,
        size: 2,
        transparent: true,
        opacity: 0.8
    });
    
    const starField = new THREE.Points(starGeometry, starMaterial);
    scene.add(starField);
    stars.push(starField);
}

function createPlayerShip() {
    const shipGroup = new THREE.Group();
    
    // Main body (fuselage)
    const bodyGeometry = new THREE.ConeGeometry(2, 6, 6);
    const bodyMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x00ffff,
        emissive: 0x0088aa,
        shininess: 100
    });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.rotation.x = Math.PI / 2;
    shipGroup.add(body);
    
    // Wings
    const wingGeometry = new THREE.BoxGeometry(8, 0.3, 3);
    const wingMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x0088aa,
        emissive: 0x004455
    });
    const wings = new THREE.Mesh(wingGeometry, wingMaterial);
    wings.position.z = -1;
    shipGroup.add(wings);
    
    // Cockpit
    const cockpitGeometry = new THREE.SphereGeometry(1, 8, 8);
    const cockpitMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xffaa00,
        emissive: 0xff6600,
        transparent: true,
        opacity: 0.8
    });
    const cockpit = new THREE.Mesh(cockpitGeometry, cockpitMaterial);
    cockpit.position.z = 1;
    shipGroup.add(cockpit);
    
    // Engines (glowing)
    const engineGeometry = new THREE.CylinderGeometry(0.4, 0.6, 2, 8);
    const engineMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xff0000,
        emissive: 0xff0000,
        emissiveIntensity: 2
    });
    
    const leftEngine = new THREE.Mesh(engineGeometry, engineMaterial);
    leftEngine.rotation.x = Math.PI / 2;
    leftEngine.position.set(-3, 0, -2);
    shipGroup.add(leftEngine);
    
    const rightEngine = new THREE.Mesh(engineGeometry, engineMaterial);
    rightEngine.rotation.x = Math.PI / 2;
    rightEngine.position.set(3, 0, -2);
    shipGroup.add(rightEngine);
    
    // Add point lights for engines
    const leftLight = new THREE.PointLight(0xff0000, 2, 10);
    leftLight.position.set(-3, 0, -3);
    shipGroup.add(leftLight);
    
    const rightLight = new THREE.PointLight(0xff0000, 2, 10);
    rightLight.position.set(3, 0, -3);
    shipGroup.add(rightLight);
    
    shipGroup.position.set(0, 0, 0);
    scene.add(shipGroup);
    
    player = shipGroup;
    player.userData = {
        health: GameState.player.health,
        maxHealth: GameState.player.maxHealth,
        bounds: { x: 40, y: 0, z: 40 }
    };
}

// ================================
// ENEMY CREATION
// ================================
function createEnemy(type = 'basic') {
    const enemyGroup = new THREE.Group();
    
    if (type === 'basic') {
        // Basic enemy
        const bodyGeometry = new THREE.OctahedronGeometry(1.5);
        const bodyMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xff0000,
            emissive: 0x880000
        });
        const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
        enemyGroup.add(body);
        
        enemyGroup.userData = {
            type: 'basic',
            health: 30,
            maxHealth: 30,
            damage: 10,
            speed: 0.2,
            score: 100,
            credits: 50
        };
    } else if (type === 'fast') {
        // Fast enemy
        const bodyGeometry = new THREE.TetrahedronGeometry(1.2);
        const bodyMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xffff00,
            emissive: 0x888800
        });
        const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
        enemyGroup.add(body);
        
        enemyGroup.userData = {
            type: 'fast',
            health: 20,
            maxHealth: 20,
            damage: 5,
            speed: 0.4,
            score: 150,
            credits: 75
        };
    } else if (type === 'tank') {
        // Tank enemy
        const bodyGeometry = new THREE.DodecahedronGeometry(2);
        const bodyMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x8800ff,
            emissive: 0x440088
        });
        const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
        enemyGroup.add(body);
        
        enemyGroup.userData = {
            type: 'tank',
            health: 60,
            maxHealth: 60,
            damage: 20,
            speed: 0.1,
            score: 200,
            credits: 100
        };
    } else if (type === 'boss') {
        // Boss enemy
        const bodyGeometry = new THREE.IcosahedronGeometry(4);
        const bodyMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xff00ff,
            emissive: 0x880088
        });
        const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
        enemyGroup.add(body);
        
        // Boss armor plates
        for (let i = 0; i < 6; i++) {
            const plateGeometry = new THREE.BoxGeometry(2, 2, 0.5);
            const plateMaterial = new THREE.MeshPhongMaterial({ 
                color: 0x000000,
                emissive: 0xff00ff
            });
            const plate = new THREE.Mesh(plateGeometry, plateMaterial);
            const angle = (i / 6) * Math.PI * 2;
            plate.position.set(Math.cos(angle) * 5, 0, Math.sin(angle) * 5);
            plate.lookAt(0, 0, 0);
            enemyGroup.add(plate);
        }
        
        enemyGroup.userData = {
            type: 'boss',
            health: 300,
            maxHealth: 300,
            damage: 50,
            speed: 0.05,
            score: 1000,
            credits: 500,
            isBoss: true
        };
    }
    
    // Random spawn position
    const spawnX = (Math.random() - 0.5) * 60;
    const spawnZ = -60 - Math.random() * 20;
    enemyGroup.position.set(spawnX, 0, spawnZ);
    
    // Add glow light
    const glowLight = new THREE.PointLight(
        enemyGroup.userData.type === 'boss' ? 0xff00ff : 0xff0000, 
        enemyGroup.userData.type === 'boss' ? 3 : 1, 
        20
    );
    enemyGroup.add(glowLight);
    
    scene.add(enemyGroup);
    enemies.push(enemyGroup);
    
    return enemyGroup;
}

// ================================
// SHOOTING SYSTEM
// ================================
function fireBullet() {
    const now = Date.now();
    if (now - GameState.lastFireTime < GameState.player.fireRate) return;
    if (GameState.player.energy < 5) return;
    
    GameState.lastFireTime = now;
    GameState.player.energy = Math.max(0, GameState.player.energy - 5);
    updateUI();
    
    // Create bullet
    const bulletGeometry = new THREE.SphereGeometry(0.3);
    const bulletMaterial = new THREE.MeshBasicMaterial({ 
        color: 0x00ffff,
        emissive: 0x00ffff,
        emissiveIntensity: 2
    });
    const bullet = new THREE.Mesh(bulletGeometry, bulletMaterial);
    
    bullet.position.copy(player.position);
    bullet.position.z -= 3;
    
    // Add bullet trail
    const trailGeometry = new THREE.CylinderGeometry(0.1, 0.3, 2);
    const trailMaterial = new THREE.MeshBasicMaterial({ 
        color: 0x00ffff,
        transparent: true,
        opacity: 0.5
    });
    const trail = new THREE.Mesh(trailGeometry, trailMaterial);
    trail.rotation.x = Math.PI / 2;
    trail.position.z = 1;
    bullet.add(trail);
    
    // Add glow
    const bulletLight = new THREE.PointLight(0x00ffff, 2, 10);
    bullet.add(bulletLight);
    
    bullet.userData = {
        speed: 1.5,
        damage: GameState.player.damage
    };
    
    scene.add(bullet);
    bullets.push(bullet);
    
    // Play sound effect (vibration)
    if (tg && tg.HapticFeedback) {
        tg.HapticFeedback.impactOccurred('light');
    }
}

function fireSpecialAttack() {
    const now = Date.now();
    if (now - GameState.lastSpecialTime < GameState.player.specialCooldown) return;
    if (GameState.player.energy < 30) return;
    
    GameState.lastSpecialTime = now;
    GameState.player.energy = Math.max(0, GameState.player.energy - 30);
    updateUI();
    
    // Create multiple bullets in a spread pattern
    for (let i = -2; i <= 2; i++) {
        const bulletGeometry = new THREE.SphereGeometry(0.5);
        const bulletMaterial = new THREE.MeshBasicMaterial({ 
            color: 0xffaa00,
            emissive: 0xffaa00,
            emissiveIntensity: 3
        });
        const bullet = new THREE.Mesh(bulletGeometry, bulletMaterial);
        
        bullet.position.copy(player.position);
        bullet.position.x += i * 2;
        bullet.position.z -= 3;
        
        const bulletLight = new THREE.PointLight(0xffaa00, 3, 15);
        bullet.add(bulletLight);
        
        bullet.userData = {
            speed: 2,
            damage: GameState.player.damage * 3,
            isSpecial: true
        };
        
        scene.add(bullet);
        bullets.push(bullet);
    }
    
    // Strong haptic feedback
    if (tg && tg.HapticFeedback) {
        tg.HapticFeedback.impactOccurred('heavy');
    }
}

// ================================
// COLLISION DETECTION
// ================================
function checkCollisions() {
    // Bullet vs Enemy
    for (let i = bullets.length - 1; i >= 0; i--) {
        const bullet = bullets[i];
        
        for (let j = enemies.length - 1; j >= 0; j--) {
            const enemy = enemies[j];
            const distance = bullet.position.distanceTo(enemy.position);
            
            if (distance < 3) {
                // Hit!
                enemy.userData.health -= bullet.userData.damage;
                
                // Create hit effect
                createExplosion(bullet.position, 0xffaa00, 10);
                
                // Remove bullet
                scene.remove(bullet);
                bullets.splice(i, 1);
                
                // Check if enemy is dead
                if (enemy.userData.health <= 0) {
                    destroyEnemy(enemy, j);
                }
                
                break;
            }
        }
    }
    
    // Enemy vs Player
    for (let i = enemies.length - 1; i >= 0; i--) {
        const enemy = enemies[i];
        const distance = enemy.position.distanceTo(player.position);
        
        if (distance < 4) {
            // Collision with player
            damagePlayer(enemy.userData.damage);
            createExplosion(enemy.position, 0xff0000, 20);
            
            // Remove enemy
            scene.remove(enemy);
            enemies.splice(i, 1);
        }
    }
}

function destroyEnemy(enemy, index) {
    // Add score and credits
    GameState.player.score += enemy.userData.score;
    GameState.player.credits += enemy.userData.credits;
    GameState.player.kills++;
    
    // Add exp
    const expGain = enemy.userData.isBoss ? 100 : 20;
    addExperience(expGain);
    
    // Show score popup
    showScorePopup(enemy.userData.score);
    
    // Create explosion
    createExplosion(enemy.position, enemy.userData.isBoss ? 0xff00ff : 0xff0000, enemy.userData.isBoss ? 50 : 20);
    
    // Chance to drop powerup
    if (Math.random() < 0.2) {
        createPowerup(enemy.position);
    }
    
    // Remove from scene
    scene.remove(enemy);
    enemies.splice(index, 1);
    
    updateUI();
    checkMissions();
    
    // Haptic feedback
    if (tg && tg.HapticFeedback) {
        tg.HapticFeedback.impactOccurred('medium');
    }
}

// ================================
// POWERUPS
// ================================
function createPowerup(position) {
    const types = ['health', 'energy', 'credits', 'weapon'];
    const type = types[Math.floor(Math.random() * types.length)];
    
    const geometry = new THREE.OctahedronGeometry(1);
    let color;
    
    switch(type) {
        case 'health': color = 0x00ff00; break;
        case 'energy': color = 0xffff00; break;
        case 'credits': color = 0xffaa00; break;
        case 'weapon': color = 0xff00ff; break;
    }
    
    const material = new THREE.MeshBasicMaterial({ 
        color: color,
        emissive: color,
        transparent: true,
        opacity: 0.8
    });
    const powerup = new THREE.Mesh(geometry, material);
    
    powerup.position.copy(position);
    powerup.userData = { type: type, rotationSpeed: 0.05 };
    
    const light = new THREE.PointLight(color, 2, 15);
    powerup.add(light);
    
    scene.add(powerup);
    powerups.push(powerup);
}

function checkPowerupCollisions() {
    for (let i = powerups.length - 1; i >= 0; i--) {
        const powerup = powerups[i];
        const distance = powerup.position.distanceTo(player.position);
        
        if (distance < 3) {
            // Collected!
            applyPowerup(powerup.userData.type);
            createExplosion(powerup.position, 0xffaa00, 15);
            
            scene.remove(powerup);
            powerups.splice(i, 1);
            
            if (tg && tg.HapticFeedback) {
                tg.HapticFeedback.notificationOccurred('success');
            }
        }
    }
}

function applyPowerup(type) {
    switch(type) {
        case 'health':
            GameState.player.health = Math.min(
                GameState.player.maxHealth, 
                GameState.player.health + 30
            );
            break;
        case 'energy':
            GameState.player.energy = Math.min(
                GameState.player.maxEnergy, 
                GameState.player.energy + 50
            );
            break;
        case 'credits':
            GameState.player.credits += 100;
            break;
        case 'weapon':
            GameState.player.damage += 2;
            setTimeout(() => {
                GameState.player.damage -= 2;
            }, 10000);
            break;
    }
    updateUI();
}

// ================================
// PARTICLE EFFECTS
// ================================
function createExplosion(position, color, particleCount) {
    for (let i = 0; i < particleCount; i++) {
        const geometry = new THREE.SphereGeometry(0.2);
        const material = new THREE.MeshBasicMaterial({ 
            color: color,
            transparent: true,
            opacity: 1
        });
        const particle = new THREE.Mesh(geometry, material);
        
        particle.position.copy(position);
        
        const angle = (i / particleCount) * Math.PI * 2;
        const speed = 0.5 + Math.random() * 0.5;
        
        particle.userData = {
            velocity: {
                x: Math.cos(angle) * speed,
                y: (Math.random() - 0.5) * speed,
                z: Math.sin(angle) * speed
            },
            life: 1.0,
            decay: 0.02
        };
        
        scene.add(particle);
        particles.push(particle);
    }
}

// ================================
// PLAYER DAMAGE & LEVEL SYSTEM
// ================================
function damagePlayer(damage) {
    const actualDamage = Math.max(1, damage - GameState.player.defense);
    GameState.player.health -= actualDamage;
    
    if (GameState.player.health <= 0) {
        gameOver();
    }
    
    updateUI();
    
    // Screen shake effect
    camera.position.x += (Math.random() - 0.5) * 2;
    camera.position.y += (Math.random() - 0.5) * 2;
}

function addExperience(amount) {
    GameState.player.exp += amount;
    
    if (GameState.player.exp >= GameState.player.expToLevel) {
        levelUp();
    }
    
    updateUI();
}

function levelUp() {
    GameState.player.level++;
    GameState.player.exp = 0;
    GameState.player.expToLevel = Math.floor(GameState.player.expToLevel * 1.5);
    
    // Increase stats
    GameState.player.maxHealth += 20;
    GameState.player.health = GameState.player.maxHealth;
    GameState.player.maxEnergy += 10;
    GameState.player.energy = GameState.player.maxEnergy;
    GameState.player.damage += 2;
    GameState.player.defense += 1;
    
    // Show level up animation
    showLevelUp();
    
    updateUI();
    checkMissions();
    
    if (tg && tg.HapticFeedback) {
        tg.HapticFeedback.notificationOccurred('success');
    }
}

// ================================
// UI UPDATES
// ================================
function updateUI() {
    // Health
    const healthPercent = (GameState.player.health / GameState.player.maxHealth) * 100;
    document.getElementById('healthFill').style.width = healthPercent + '%';
    document.getElementById('healthText').textContent = Math.floor(GameState.player.health);
    
    // Energy
    const energyPercent = (GameState.player.energy / GameState.player.maxEnergy) * 100;
    document.getElementById('energyFill').style.width = energyPercent + '%';
    document.getElementById('energyText').textContent = Math.floor(GameState.player.energy);
    
    // Experience
    const expPercent = (GameState.player.exp / GameState.player.expToLevel) * 100;
    document.getElementById('expFill').style.width = expPercent + '%';
    document.getElementById('levelText').textContent = GameState.player.level;
    
    // Credits and Score
    document.getElementById('creditsText').textContent = GameState.player.credits;
    document.getElementById('killsText').textContent = GameState.player.kills;
    document.getElementById('scoreText').textContent = GameState.player.score;
}

function showScorePopup(score) {
    const scoreDisplay = document.getElementById('scoreDisplay');
    scoreDisplay.textContent = '+' + score;
    scoreDisplay.classList.remove('show');
    void scoreDisplay.offsetWidth; // Trigger reflow
    scoreDisplay.classList.add('show');
    
    setTimeout(() => {
        scoreDisplay.classList.remove('show');
    }, 1000);
}

function showLevelUp() {
    const levelUp = document.getElementById('levelUp');
    levelUp.textContent = 'LEVEL ' + GameState.player.level + '!';
    levelUp.classList.remove('show');
    void levelUp.offsetWidth;
    levelUp.classList.add('show');
    
    setTimeout(() => {
        levelUp.classList.remove('show');
    }, 2000);
}

// ================================
// MISSIONS SYSTEM
// ================================
function checkMissions() {
    GameState.missions.forEach(mission => {
        if (mission.completed) return;
        
        let progress = 0;
        switch(mission.id) {
            case 1: progress = GameState.player.kills; break;
            case 2: progress = GameState.player.credits; break;
            case 3: progress = GameState.player.level; break;
            case 4: progress = GameState.player.kills; break; // Boss kills would need separate counter
            case 5: progress = GameState.player.score; break;
        }
        
        if (progress >= mission.target) {
            completeMission(mission);
        }
    });
}

function completeMission(mission) {
    mission.completed = true;
    GameState.player.credits += mission.reward;
    
    showMissionAlert(mission);
    updateUI();
}

function showMissionAlert(mission) {
    const alert = document.getElementById('missionAlert');
    const textEl = document.getElementById('missionText');
    const rewardEl = document.getElementById('missionReward');
    
    textEl.textContent = mission.title + ' - Выполнено!';
    rewardEl.textContent = '💰 Награда: ' + mission.reward + ' кредитов';
    
    alert.classList.add('show');
    
    setTimeout(() => {
        alert.classList.remove('show');
    }, 3000);
}

// ================================
// UPGRADE SYSTEM
// ================================
const UPGRADES = [
    {
        id: 'weapon',
        name: '🔫 Оружие',
        desc: 'Урон +5',
        baseCost: 500,
        apply: () => { GameState.player.damage += 5; }
    },
    {
        id: 'shield',
        name: '🛡️ Щит',
        desc: 'Защита +2',
        baseCost: 400,
        apply: () => { GameState.player.defense += 2; }
    },
    {
        id: 'engine',
        name: '🚀 Двигатель',
        desc: 'Скорость +20%',
        baseCost: 600,
        apply: () => { GameState.player.speed *= 1.2; }
    },
    {
        id: 'energy',
        name: '⚡ Энергия',
        desc: 'Макс. энергия +20',
        baseCost: 300,
        apply: () => { 
            GameState.player.maxEnergy += 20;
            GameState.player.energy = GameState.player.maxEnergy;
        }
    },
    {
        id: 'special',
        name: '💫 Спец. атака',
        desc: 'Перезарядка -20%',
        baseCost: 800,
        apply: () => { GameState.player.specialCooldown *= 0.8; }
    },
    {
        id: 'health',
        name: '❤️ Здоровье',
        desc: 'Макс. HP +30',
        baseCost: 400,
        apply: () => { 
            GameState.player.maxHealth += 30;
            GameState.player.health = GameState.player.maxHealth;
        }
    }
];

function initUpgradeMenu() {
    const grid = document.getElementById('upgradeGrid');
    grid.innerHTML = '';
    
    UPGRADES.forEach(upgrade => {
        const level = GameState.player.upgrades[upgrade.id + 'Level'] || 1;
        const cost = Math.floor(upgrade.baseCost * Math.pow(1.5, level - 1));
        const canAfford = GameState.player.credits >= cost;
        
        const card = document.createElement('div');
        card.className = 'upgrade-card' + (canAfford ? '' : ' locked');
        card.innerHTML = `
            <div class="upgrade-name">${upgrade.name}</div>
            <div style="font-size: 12px; color: #aaa;">Уровень: ${level}</div>
            <div style="font-size: 12px; margin: 8px 0;">${upgrade.desc}</div>
            <div class="upgrade-cost">💰 ${cost}</div>
        `;
        
        if (canAfford) {
            card.onclick = () => purchaseUpgrade(upgrade);
        }
        
        grid.appendChild(card);
    });
}

function purchaseUpgrade(upgrade) {
    const level = GameState.player.upgrades[upgrade.id + 'Level'] || 1;
    const cost = Math.floor(upgrade.baseCost * Math.pow(1.5, level - 1));
    
    if (GameState.player.credits >= cost) {
        GameState.player.credits -= cost;
        GameState.player.upgrades[upgrade.id + 'Level'] = level + 1;
        upgrade.apply();
        
        updateUI();
        initUpgradeMenu();
        
        if (tg && tg.HapticFeedback) {
            tg.HapticFeedback.notificationOccurred('success');
        }
    }
}

function toggleMenu() {
    const modal = document.getElementById('menuModal');
    modal.classList.toggle('active');
    
    if (modal.classList.contains('active')) {
        initUpgradeMenu();
        GameState.isPaused = true;
    } else {
        GameState.isPaused = false;
    }
}

// ================================
// ENEMY SPAWNING
// ================================
function spawnEnemyWave() {
    const wave = GameState.settings.waveNumber;
    const enemyCount = Math.min(GameState.settings.enemiesPerWave + Math.floor(wave / 2), 15);
    
    // Spawn boss every 5 waves
    if (wave % GameState.settings.bossEvery === 0 && enemies.length === 0) {
        createEnemy('boss');
        return;
    }
    
    for (let i = 0; i < enemyCount; i++) {
        const rand = Math.random();
        let type = 'basic';
        
        if (rand < 0.1) type = 'tank';
        else if (rand < 0.3) type = 'fast';
        
        setTimeout(() => {
            createEnemy(type);
        }, i * 300);
    }
    
    GameState.settings.waveNumber++;
}

// ================================
// GAME LOOP
// ================================
function gameLoop() {
    if (!GameState.isRunning) return;
    
    requestAnimationFrame(gameLoop);
    
    if (GameState.isPaused) {
        renderer.render(scene, camera);
        return;
    }
    
    const delta = clock.getDelta();
    const time = clock.getElapsedTime();
    
    // Update player movement
    if (player && joystickActive) {
        player.position.x += joystickVector.x * GameState.player.speed;
        player.position.z += joystickVector.y * GameState.player.speed;
        
        // Keep player in bounds
        const bounds = player.userData.bounds;
        player.position.x = Math.max(-bounds.x, Math.min(bounds.x, player.position.x));
        player.position.z = Math.max(-bounds.z, Math.min(bounds.z, player.position.z));
        
        // Tilt ship based on movement
        player.rotation.z = -joystickVector.x * 0.3;
        player.rotation.x = joystickVector.y * 0.2;
    } else if (player) {
        // Reset rotation
        player.rotation.z *= 0.9;
        player.rotation.x *= 0.9;
    }
    
    // Update bullets
    for (let i = bullets.length - 1; i >= 0; i--) {
        const bullet = bullets[i];
        bullet.position.z -= bullet.userData.speed;
        
        // Remove if out of bounds
        if (bullet.position.z < -100) {
            scene.remove(bullet);
            bullets.splice(i, 1);
        }
    }
    
    // Update enemies
    for (let i = enemies.length - 1; i >= 0; i--) {
        const enemy = enemies[i];
        enemy.position.z += enemy.userData.speed;
        enemy.rotation.y += 0.02;
        
        // Remove if out of bounds
        if (enemy.position.z > 100) {
            scene.remove(enemy);
            enemies.splice(i, 1);
        }
    }
    
    // Update powerups
    for (let i = powerups.length - 1; i >= 0; i--) {
        const powerup = powerups[i];
        powerup.rotation.y += powerup.userData.rotationSpeed;
        powerup.position.y = Math.sin(time * 2 + i) * 0.5;
        powerup.position.z += 0.1;
        
        // Remove if out of bounds
        if (powerup.position.z > 100) {
            scene.remove(powerup);
            powerups.splice(i, 1);
        }
    }
    
    // Update particles
    for (let i = particles.length - 1; i >= 0; i--) {
        const particle = particles[i];
        particle.position.x += particle.userData.velocity.x;
        particle.position.y += particle.userData.velocity.y;
        particle.position.z += particle.userData.velocity.z;
        
        particle.userData.life -= particle.userData.decay;
        particle.material.opacity = particle.userData.life;
        
        if (particle.userData.life <= 0) {
            scene.remove(particle);
            particles.splice(i, 1);
        }
    }
    
    // Animate stars
    stars.forEach(star => {
        star.rotation.y += 0.0001;
    });
    
    // Energy regeneration
    GameState.energyRegenTimer += delta;
    if (GameState.energyRegenTimer >= 0.5) {
        GameState.energyRegenTimer = 0;
        GameState.player.energy = Math.min(
            GameState.player.maxEnergy,
            GameState.player.energy + 2
        );
        updateUI();
    }
    
    // Enemy spawning
    GameState.enemySpawnTimer += delta;
    if (GameState.enemySpawnTimer >= 5 && enemies.length < 10) {
        GameState.enemySpawnTimer = 0;
        spawnEnemyWave();
    }
    
    // Check collisions
    checkCollisions();
    checkPowerupCollisions();
    
    // Update minimap
    updateMinimap();
    
    // Render scene
    renderer.render(scene, camera);
}

// ================================
// MINIMAP
// ================================
function updateMinimap() {
    const canvas = document.getElementById('minimapCanvas');
    const ctx = canvas.getContext('2d');
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(0, 0, 150, 150);
    
    // Draw player
    ctx.fillStyle = '#00ffff';
    ctx.fillRect(
        75 + player.position.x * 1.5,
        75 + player.position.z * 1.5,
        4, 4
    );
    
    // Draw enemies
    ctx.fillStyle = '#ff0000';
    enemies.forEach(enemy => {
        const x = 75 + enemy.position.x * 1.5;
        const z = 75 + enemy.position.z * 1.5;
        if (x >= 0 && x <= 150 && z >= 0 && z <= 150) {
            ctx.fillRect(x, z, 3, 3);
        }
    });
}

// ================================
// CONTROLS
// ================================
function initControls() {
    const joystick = document.getElementById('joystick');
    const joystickKnob = document.getElementById('joystickKnob');
    const fireBtn = document.getElementById('fireBtn');
    const specialBtn = document.getElementById('specialBtn');
    
    // Joystick
    let joystickCenter = { x: 0, y: 0 };
    let joystickMaxDistance = 35;
    
    function handleJoystickStart(e) {
        joystickActive = true;
        const rect = joystick.getBoundingClientRect();
        joystickCenter = {
            x: rect.left + rect.width / 2,
            y: rect.top + rect.height / 2
        };
    }
    
    function handleJoystickMove(e) {
        if (!joystickActive) return;
        
        const touch = e.touches ? e.touches[0] : e;
        const dx = touch.clientX - joystickCenter.x;
        const dy = touch.clientY - joystickCenter.y;
        
        const distance = Math.sqrt(dx * dx + dy * dy);
        const angle = Math.atan2(dy, dx);
        
        const limitedDistance = Math.min(distance, joystickMaxDistance);
        
        joystickKnob.style.transform = `translate(-50%, -50%) translate(${
            Math.cos(angle) * limitedDistance
        }px, ${
            Math.sin(angle) * limitedDistance
        }px)`;
        
        joystickVector.x = (Math.cos(angle) * limitedDistance) / joystickMaxDistance;
        joystickVector.y = (Math.sin(angle) * limitedDistance) / joystickMaxDistance;
    }
    
    function handleJoystickEnd() {
        joystickActive = false;
        joystickKnob.style.transform = 'translate(-50%, -50%)';
        joystickVector.x = 0;
        joystickVector.y = 0;
    }
    
    joystick.addEventListener('touchstart', handleJoystickStart);
    joystick.addEventListener('touchmove', handleJoystickMove);
    joystick.addEventListener('touchend', handleJoystickEnd);
    joystick.addEventListener('mousedown', handleJoystickStart);
    document.addEventListener('mousemove', handleJoystickMove);
    document.addEventListener('mouseup', handleJoystickEnd);
    
    // Fire button
    let fireInterval;
    
    fireBtn.addEventListener('touchstart', (e) => {
        e.preventDefault();
        fireBullet();
        fireInterval = setInterval(fireBullet, GameState.player.fireRate);
    });
    
    fireBtn.addEventListener('touchend', () => {
        clearInterval(fireInterval);
    });
    
    fireBtn.addEventListener('mousedown', () => {
        fireBullet();
        fireInterval = setInterval(fireBullet, GameState.player.fireRate);
    });
    
    fireBtn.addEventListener('mouseup', () => {
        clearInterval(fireInterval);
    });
    
    // Special button
    specialBtn.addEventListener('touchstart', (e) => {
        e.preventDefault();
        fireSpecialAttack();
    });
    
    specialBtn.addEventListener('click', () => {
        fireSpecialAttack();
    });
}

// ================================
// GAME START/STOP
// ================================
function startGame() {
    document.getElementById('startScreen').style.display = 'none';
    document.getElementById('gameUI').style.display = 'block';
    document.getElementById('loading').classList.add('hidden');
    
    GameState.isRunning = true;
    
    initControls();
    spawnEnemyWave();
    gameLoop();
    
    updateUI();
}

function gameOver() {
    GameState.isRunning = false;
    
    alert(`Game Over!\nСчет: ${GameState.player.score}\nУровень: ${GameState.player.level}\nУбийств: ${GameState.player.kills}`);
    
    // Send score to Telegram
    if (tg && tg.close) {
        tg.showAlert('Игра окончена! Счет: ' + GameState.player.score, () => {
            tg.close();
        });
    }
    
    location.reload();
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

// ================================
// INITIALIZATION
// ================================
window.addEventListener('load', () => {
    initThreeJS();
    
    setTimeout(() => {
        document.getElementById('loading').classList.add('hidden');
    }, 1000);
});
