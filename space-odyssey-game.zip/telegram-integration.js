/**
 * Telegram Integration & Monetization Module
 * Handles Telegram WebApp API and payment integration
 */

// ================================
// TELEGRAM INITIALIZATION
// ================================

class TelegramIntegration {
    constructor() {
        this.tg = window.Telegram?.WebApp;
        this.isAvailable = !!this.tg;
        this.userId = null;
        this.username = null;
        
        if (this.isAvailable) {
            this.init();
        }
    }
    
    init() {
        this.tg.ready();
        this.tg.expand();
        
        // Get user data
        const user = this.tg.initDataUnsafe?.user;
        if (user) {
            this.userId = user.id;
            this.username = user.username || user.first_name;
        }
        
        // Set theme colors
        this.applyTheme();
        
        // Setup main button
        this.setupMainButton();
        
        console.log('✅ Telegram integration initialized');
    }
    
    applyTheme() {
        const themeParams = this.tg.themeParams;
        
        if (themeParams.bg_color) {
            document.documentElement.style.setProperty(
                '--tg-theme-bg-color',
                themeParams.bg_color
            );
        }
        
        if (themeParams.button_color) {
            document.documentElement.style.setProperty(
                '--tg-theme-button-color',
                themeParams.button_color
            );
        }
    }
    
    setupMainButton() {
        this.tg.MainButton.setText('💰 Магазин');
        this.tg.MainButton.onClick(() => {
            this.openShop();
        });
    }
    
    showMainButton() {
        if (this.isAvailable) {
            this.tg.MainButton.show();
        }
    }
    
    hideMainButton() {
        if (this.isAvailable) {
            this.tg.MainButton.hide();
        }
    }
    
    // ================================
    // HAPTIC FEEDBACK
    // ================================
    
    hapticImpact(style = 'medium') {
        if (this.isAvailable && this.tg.HapticFeedback) {
            this.tg.HapticFeedback.impactOccurred(style);
        }
    }
    
    hapticNotification(type = 'success') {
        if (this.isAvailable && this.tg.HapticFeedback) {
            this.tg.HapticFeedback.notificationOccurred(type);
        }
    }
    
    hapticSelection() {
        if (this.isAvailable && this.tg.HapticFeedback) {
            this.tg.HapticFeedback.selectionChanged();
        }
    }
    
    // ================================
    // PAYMENT SYSTEM (Telegram Stars)
    // ================================
    
    async openInvoice(item) {
        if (!this.isAvailable) {
            console.error('Telegram WebApp not available');
            return false;
        }
        
        try {
            // Create invoice link
            const invoiceLink = await this.createInvoiceLink(item);
            
            // Open invoice
            this.tg.openInvoice(invoiceLink, (status) => {
                if (status === 'paid') {
                    this.handleSuccessfulPayment(item);
                } else if (status === 'cancelled') {
                    this.handleCancelledPayment();
                } else if (status === 'failed') {
                    this.handleFailedPayment();
                }
            });
            
            return true;
        } catch (error) {
            console.error('Error opening invoice:', error);
            this.showAlert('Ошибка при открытии платежа');
            return false;
        }
    }
    
    async createInvoiceLink(item) {
        // In production, this would call your backend API
        // which creates invoice using Telegram Bot API
        
        const payload = {
            title: item.name,
            description: item.description,
            payload: JSON.stringify({
                user_id: this.userId,
                item_id: item.id
            }),
            provider_token: '', // Use Telegram Stars
            currency: 'XTR', // Telegram Stars currency code
            prices: [{
                label: item.name,
                amount: item.price // Amount in Stars
            }]
        };
        
        // Call backend to create invoice
        const response = await fetch('/api/create-invoice', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload)
        });
        
        const data = await response.json();
        return data.invoice_link;
    }
    
    async handleSuccessfulPayment(item) {
        this.hapticNotification('success');
        
        // Apply purchase to game
        await this.applyPurchase(item);
        
        this.showAlert('✅ Покупка успешна!');
        
        // Save to backend
        this.savePlayerProgress();
    }
    
    handleCancelledPayment() {
        this.hapticNotification('warning');
        this.showAlert('Платеж отменен');
    }
    
    handleFailedPayment() {
        this.hapticNotification('error');
        this.showAlert('❌ Ошибка платежа. Попробуйте снова.');
    }
    
    async applyPurchase(item) {
        switch(item.id) {
            case 'credits_100':
                GameState.player.credits += 100;
                break;
            case 'credits_500':
                GameState.player.credits += 500;
                break;
            case 'credits_1000':
                GameState.player.credits += 1000;
                break;
            case 'premium_ship':
                GameState.player.damage += 10;
                GameState.player.maxHealth += 50;
                GameState.player.health = GameState.player.maxHealth;
                GameState.player.upgrades.premium = true;
                break;
            case 'energy_boost':
                GameState.player.energyBoost = Date.now() + 86400000; // 24 hours
                break;
            case 'double_exp':
                GameState.player.doubleExp = Date.now() + 86400000; // 24 hours
                break;
        }
        
        updateUI();
    }
    
    // ================================
    // SHOP INTERFACE
    // ================================
    
    async openShop() {
        const shopHTML = `
            <div class="shop-container">
                <div class="shop-header">
                    <h2>💰 Магазин</h2>
                    <p>Покупки через Telegram Stars</p>
                </div>
                <div class="shop-items" id="shopItems">
                    ${await this.getShopItemsHTML()}
                </div>
            </div>
        `;
        
        const modal = document.getElementById('menuModal');
        const content = modal.querySelector('.modal-content');
        content.innerHTML = shopHTML;
        modal.classList.add('active');
        
        // Setup item click handlers
        this.setupShopHandlers();
    }
    
    async getShopItemsHTML() {
        const response = await fetch('/api/shop/items');
        const data = await response.json();
        
        return data.items.map(item => `
            <div class="shop-item" data-item-id="${item.id}">
                <div class="shop-item-name">${item.name}</div>
                <div class="shop-item-desc">${item.description}</div>
                ${item.discount ? `<div class="shop-discount">${item.discount}</div>` : ''}
                <div class="shop-item-price">
                    <span class="stars-icon">⭐</span>
                    ${item.price} Stars
                </div>
                <button class="shop-buy-btn">Купить</button>
            </div>
        `).join('');
    }
    
    setupShopHandlers() {
        const items = document.querySelectorAll('.shop-item');
        
        items.forEach(item => {
            const buyBtn = item.querySelector('.shop-buy-btn');
            const itemId = item.dataset.itemId;
            
            buyBtn.addEventListener('click', async () => {
                this.hapticImpact('light');
                
                const itemData = await this.getItemData(itemId);
                await this.openInvoice(itemData);
            });
        });
    }
    
    async getItemData(itemId) {
        const response = await fetch('/api/shop/items');
        const data = await response.json();
        return data.items.find(item => item.id === itemId);
    }
    
    // ================================
    // BACKEND INTEGRATION
    // ================================
    
    async savePlayerProgress() {
        if (!this.userId) {
            console.warn('No user ID, cannot save progress');
            return;
        }
        
        try {
            const response = await fetch('/api/player/save', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    telegram_id: this.userId,
                    username: this.username,
                    ...GameState.player
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                console.log('✅ Progress saved');
                return true;
            }
        } catch (error) {
            console.error('Error saving progress:', error);
        }
        
        return false;
    }
    
    async loadPlayerProgress() {
        if (!this.userId) {
            console.warn('No user ID, cannot load progress');
            return null;
        }
        
        try {
            const response = await fetch(`/api/player/${this.userId}`);
            const data = await response.json();
            
            if (data.success) {
                console.log('✅ Progress loaded');
                return data.data;
            }
        } catch (error) {
            console.error('Error loading progress:', error);
        }
        
        return null;
    }
    
    async getLeaderboard() {
        try {
            const response = await fetch('/api/leaderboard?limit=10');
            const data = await response.json();
            
            if (data.success) {
                return data.leaderboard;
            }
        } catch (error) {
            console.error('Error fetching leaderboard:', error);
        }
        
        return [];
    }
    
    async showLeaderboard() {
        const leaderboard = await this.getLeaderboard();
        
        const leaderboardHTML = `
            <div class="leaderboard-container">
                <h2>🏆 Топ игроков</h2>
                <div class="leaderboard-list">
                    ${leaderboard.map((entry, index) => `
                        <div class="leaderboard-entry ${entry.telegram_id === this.userId ? 'highlight' : ''}">
                            <span class="rank">${index + 1}</span>
                            <span class="username">${entry.username}</span>
                            <span class="score">${entry.score}</span>
                            <span class="level">Ур. ${entry.level}</span>
                        </div>
                    `).join('')}
                </div>
                <button class="close-btn" onclick="toggleMenu()">Закрыть</button>
            </div>
        `;
        
        const modal = document.getElementById('menuModal');
        const content = modal.querySelector('.modal-content');
        content.innerHTML = leaderboardHTML;
        modal.classList.add('active');
    }
    
    // ================================
    // UTILITY METHODS
    // ================================
    
    showAlert(message) {
        if (this.isAvailable) {
            this.tg.showAlert(message);
        } else {
            alert(message);
        }
    }
    
    showConfirm(message, callback) {
        if (this.isAvailable) {
            this.tg.showConfirm(message, callback);
        } else {
            const result = confirm(message);
            callback(result);
        }
    }
    
    showPopup(params) {
        if (this.isAvailable) {
            this.tg.showPopup(params);
        }
    }
    
    close() {
        if (this.isAvailable) {
            this.tg.close();
        }
    }
    
    shareScore() {
        if (this.isAvailable) {
            const text = `🚀 Я набрал ${GameState.player.score} очков в Space Odyssey! Сможешь побить мой рекорд?`;
            const url = `https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(text)}`;
            window.open(url, '_blank');
        }
    }
}

// ================================
// AUTO-SAVE SYSTEM
// ================================

class AutoSaveManager {
    constructor(telegram, intervalMs = 30000) {
        this.telegram = telegram;
        this.intervalMs = intervalMs;
        this.saveTimer = null;
        this.lastSave = Date.now();
    }
    
    start() {
        this.saveTimer = setInterval(() => {
            this.save();
        }, this.intervalMs);
        
        // Save on visibility change
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.save();
            }
        });
        
        // Save on beforeunload
        window.addEventListener('beforeunload', () => {
            this.save();
        });
    }
    
    async save() {
        const now = Date.now();
        if (now - this.lastSave < 5000) {
            return; // Don't save too frequently
        }
        
        const success = await this.telegram.savePlayerProgress();
        if (success) {
            this.lastSave = now;
            console.log('🔄 Auto-saved at', new Date().toLocaleTimeString());
        }
    }
    
    stop() {
        if (this.saveTimer) {
            clearInterval(this.saveTimer);
            this.saveTimer = null;
        }
    }
}

// ================================
// INITIALIZE ON LOAD
// ================================

let telegramIntegration;
let autoSaveManager;

window.addEventListener('load', async () => {
    // Initialize Telegram integration
    telegramIntegration = new TelegramIntegration();
    
    if (telegramIntegration.isAvailable) {
        // Load saved progress
        const savedProgress = await telegramIntegration.loadPlayerProgress();
        
        if (savedProgress) {
            // Restore player state
            Object.assign(GameState.player, savedProgress);
            updateUI();
            
            telegramIntegration.showAlert('Прогресс загружен! 🎮');
        }
        
        // Start auto-save
        autoSaveManager = new AutoSaveManager(telegramIntegration);
        autoSaveManager.start();
        
        // Show main button
        telegramIntegration.showMainButton();
    }
});

// ================================
// EXPORT FOR GLOBAL ACCESS
// ================================

window.TelegramGame = {
    integration: telegramIntegration,
    autoSave: autoSaveManager,
    
    openShop: () => telegramIntegration?.openShop(),
    showLeaderboard: () => telegramIntegration?.showLeaderboard(),
    shareScore: () => telegramIntegration?.shareScore(),
    saveProgress: () => telegramIntegration?.savePlayerProgress()
};
