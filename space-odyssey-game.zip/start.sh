#!/bin/bash

# ================================
# Space Odyssey - Quick Start Script
# Скрипт для быстрого запуска игры
# ================================

echo "🚀 Space Odyssey - Quick Start"
echo "==============================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Check Python
check_python() {
    if command -v python3 &> /dev/null; then
        print_success "Python3 найден"
        PYTHON_CMD="python3"
        return 0
    elif command -v python &> /dev/null; then
        print_success "Python найден"
        PYTHON_CMD="python"
        return 0
    else
        print_error "Python не найден. Установите Python 3.7+"
        return 1
    fi
}

# Check files
check_files() {
    print_info "Проверка файлов..."
    
    required_files=("index.html" "game.js" "telegram-integration.js")
    all_found=true
    
    for file in "${required_files[@]}"; do
        if [ -f "$file" ]; then
            print_success "$file найден"
        else
            print_error "$file не найден"
            all_found=false
        fi
    done
    
    if [ "$all_found" = true ]; then
        return 0
    else
        return 1
    fi
}

# Start frontend only
start_frontend() {
    print_info "Запуск frontend сервера..."
    echo ""
    print_success "Сервер запущен на http://localhost:8080"
    print_info "Нажмите Ctrl+C для остановки"
    echo ""
    $PYTHON_CMD -m http.server 8080
}

# Install backend dependencies
install_backend_deps() {
    print_info "Установка зависимостей backend..."
    
    if [ -f "requirements.txt" ]; then
        $PYTHON_CMD -m pip install -r requirements.txt
        if [ $? -eq 0 ]; then
            print_success "Зависимости установлены"
            return 0
        else
            print_error "Ошибка установки зависимостей"
            return 1
        fi
    else
        print_error "requirements.txt не найден"
        return 1
    fi
}

# Start backend
start_backend() {
    print_info "Запуск backend сервера..."
    
    if [ -f "server.py" ]; then
        $PYTHON_CMD server.py &
        BACKEND_PID=$!
        sleep 2
        
        # Check if backend is running
        if ps -p $BACKEND_PID > /dev/null; then
            print_success "Backend запущен на http://localhost:8000"
            print_info "Backend PID: $BACKEND_PID"
            return 0
        else
            print_error "Ошибка запуска backend"
            return 1
        fi
    else
        print_error "server.py не найден"
        return 1
    fi
}

# Start full stack
start_full() {
    # Check and install backend dependencies
    if ! install_backend_deps; then
        print_error "Не удалось установить зависимости backend"
        exit 1
    fi
    
    # Start backend
    if ! start_backend; then
        print_error "Не удалось запустить backend"
        exit 1
    fi
    
    sleep 2
    
    # Start frontend
    print_info "Запуск frontend сервера..."
    echo ""
    print_success "Frontend: http://localhost:8080"
    print_success "Backend API: http://localhost:8000"
    print_success "API Docs: http://localhost:8000/docs"
    echo ""
    print_info "Нажмите Ctrl+C для остановки"
    echo ""
    
    $PYTHON_CMD -m http.server 8080
}

# Test deployment
test_deployment() {
    print_info "Тестирование деплоя..."
    echo ""
    
    # Test frontend
    print_info "Проверка frontend..."
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:8080 | grep -q "200"; then
        print_success "Frontend работает"
    else
        print_warning "Frontend недоступен"
    fi
    
    # Test backend
    if [ -f "server.py" ]; then
        print_info "Проверка backend..."
        if curl -s -o /dev/null -w "%{http_code}" http://localhost:8000 | grep -q "200"; then
            print_success "Backend работает"
        else
            print_warning "Backend недоступен"
        fi
    fi
    
    echo ""
}

# Open browser
open_browser() {
    URL="http://localhost:8080"
    
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        open "$URL"
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux
        xdg-open "$URL" 2>/dev/null || print_warning "Откройте браузер вручную: $URL"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
        # Windows
        start "$URL"
    fi
}

# Show menu
show_menu() {
    echo ""
    echo "Выберите режим запуска:"
    echo ""
    echo "  1) Frontend только (без сохранений)"
    echo "  2) Full-stack (frontend + backend)"
    echo "  3) Установить backend зависимости"
    echo "  4) Тест деплоя"
    echo "  5) Показать информацию"
    echo "  0) Выход"
    echo ""
}

# Show info
show_info() {
    echo ""
    echo "📋 Информация о проекте"
    echo "======================="
    echo ""
    echo "Название: Space Odyssey"
    echo "Версия: 1.0.0"
    echo "Тип: 3D Space RPG для Telegram Mini Apps"
    echo ""
    echo "📁 Файлы:"
    echo "  - index.html           (Главная страница)"
    echo "  - game.js              (Игровой движок)"
    echo "  - telegram-integration.js (Telegram API)"
    echo "  - server.py            (Backend сервер)"
    echo ""
    echo "🌐 Порты:"
    echo "  - Frontend: http://localhost:8080"
    echo "  - Backend:  http://localhost:8000"
    echo "  - API Docs: http://localhost:8000/docs"
    echo ""
    echo "📚 Документация:"
    echo "  - README.md            (Основная документация)"
    echo "  - DEPLOYMENT.md        (Инструкции по деплою)"
    echo "  - PROJECT_OVERVIEW.md  (Обзор проекта)"
    echo "  - LAUNCH_CHECKLIST.md  (Чеклист запуска)"
    echo ""
}

# Main script
main() {
    # Check Python
    if ! check_python; then
        exit 1
    fi
    
    # Check files
    if ! check_files; then
        print_error "Не все файлы найдены. Убедитесь, что вы в правильной директории."
        exit 1
    fi
    
    echo ""
    
    # Show menu if no arguments
    if [ $# -eq 0 ]; then
        while true; do
            show_menu
            read -p "Ваш выбор: " choice
            
            case $choice in
                1)
                    echo ""
                    start_frontend
                    break
                    ;;
                2)
                    echo ""
                    start_full
                    break
                    ;;
                3)
                    echo ""
                    install_backend_deps
                    read -p "Нажмите Enter для продолжения..."
                    ;;
                4)
                    echo ""
                    test_deployment
                    read -p "Нажмите Enter для продолжения..."
                    ;;
                5)
                    show_info
                    read -p "Нажмите Enter для продолжения..."
                    ;;
                0)
                    echo ""
                    print_info "До свидания! 🚀"
                    exit 0
                    ;;
                *)
                    print_error "Неверный выбор"
                    ;;
            esac
        done
    else
        # Handle command line arguments
        case $1 in
            --frontend|-f)
                start_frontend
                ;;
            --full|-F)
                start_full
                ;;
            --install|-i)
                install_backend_deps
                ;;
            --test|-t)
                test_deployment
                ;;
            --info)
                show_info
                ;;
            --help|-h)
                echo "Usage: $0 [OPTION]"
                echo ""
                echo "Options:"
                echo "  -f, --frontend    Запустить только frontend"
                echo "  -F, --full        Запустить full-stack"
                echo "  -i, --install     Установить backend зависимости"
                echo "  -t, --test        Тест деплоя"
                echo "  --info            Показать информацию"
                echo "  -h, --help        Показать помощь"
                echo ""
                ;;
            *)
                print_error "Неизвестная команда: $1"
                echo "Используйте --help для списка команд"
                exit 1
                ;;
        esac
    fi
}

# Run main
main "$@"
