"""
SPACE ODYSSEY - Backend Server
FastAPI server for game data management
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import json
import os
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = FastAPI(title="Space Odyssey API")

# Configuration from environment
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
DATA_FILE = os.getenv('DATA_FILE', 'game_data.json')
ADMIN_KEY = os.getenv('ADMIN_KEY', 'space_odyssey_admin_2025')
GAME_NAME = os.getenv('GAME_NAME', 'Space Odyssey')
GAME_VERSION = os.getenv('GAME_VERSION', '1.0.0')

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Data storage file
DATA_FILE = "game_data.json"

# ================================
# DATA MODELS
# ================================

class PlayerStats(BaseModel):
    telegram_id: int
    username: str
    level: int
    score: int
    credits: int
    kills: int
    health: int
    maxHealth: int
    energy: int
    maxEnergy: int
    exp: int
    expToLevel: int
    damage: int
    defense: int
    upgrades: dict
    missions_completed: List[int] = []
    last_played: str

class LeaderboardEntry(BaseModel):
    telegram_id: int
    username: str
    score: int
    level: int
    kills: int

class PurchaseRequest(BaseModel):
    telegram_id: int
    item_id: str
    amount: int

# ================================
# DATA MANAGEMENT
# ================================

def load_data():
    """Load game data from JSON file"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "players": {},
        "leaderboard": [],
        "purchases": []
    }

def save_data(data):
    """Save game data to JSON file"""
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# ================================
# API ENDPOINTS
# ================================

@app.get("/")
async def root():
    """API health check"""
    return {
        "status": "online",
        "game": "Space Odyssey",
        "version": "1.0.0"
    }

@app.post("/api/player/save")
async def save_player(stats: PlayerStats):
    """Save player progress"""
    data = load_data()
    
    stats.last_played = datetime.now().isoformat()
    data["players"][str(stats.telegram_id)] = stats.dict()
    
    # Update leaderboard
    update_leaderboard(data, stats)
    
    save_data(data)
    
    return {
        "success": True,
        "message": "Прогресс сохранен",
        "timestamp": stats.last_played
    }

@app.get("/api/player/{telegram_id}")
async def get_player(telegram_id: int):
    """Get player progress"""
    data = load_data()
    
    player_key = str(telegram_id)
    if player_key in data["players"]:
        return {
            "success": True,
            "data": data["players"][player_key]
        }
    
    raise HTTPException(status_code=404, detail="Игрок не найден")

@app.get("/api/leaderboard")
async def get_leaderboard(limit: int = 100):
    """Get top players leaderboard"""
    data = load_data()
    
    leaderboard = sorted(
        data["leaderboard"],
        key=lambda x: x["score"],
        reverse=True
    )[:limit]
    
    return {
        "success": True,
        "leaderboard": leaderboard,
        "total_players": len(data["players"])
    }

@app.get("/api/leaderboard/level")
async def get_level_leaderboard(limit: int = 100):
    """Get leaderboard by level"""
    data = load_data()
    
    leaderboard = sorted(
        data["leaderboard"],
        key=lambda x: (x["level"], x["score"]),
        reverse=True
    )[:limit]
    
    return {
        "success": True,
        "leaderboard": leaderboard
    }

@app.get("/api/leaderboard/kills")
async def get_kills_leaderboard(limit: int = 100):
    """Get leaderboard by kills"""
    data = load_data()
    
    leaderboard = sorted(
        data["leaderboard"],
        key=lambda x: x["kills"],
        reverse=True
    )[:limit]
    
    return {
        "success": True,
        "leaderboard": leaderboard
    }

@app.post("/api/purchase")
async def process_purchase(purchase: PurchaseRequest):
    """Process in-game purchase via Telegram Stars"""
    data = load_data()
    
    # Verify player exists
    player_key = str(purchase.telegram_id)
    if player_key not in data["players"]:
        raise HTTPException(status_code=404, detail="Игрок не найден")
    
    # Process purchase
    purchase_record = {
        "telegram_id": purchase.telegram_id,
        "item_id": purchase.item_id,
        "amount": purchase.amount,
        "timestamp": datetime.now().isoformat()
    }
    
    data["purchases"].append(purchase_record)
    
    # Apply purchase rewards
    player = data["players"][player_key]
    
    if purchase.item_id == "credits_100":
        player["credits"] += 100
    elif purchase.item_id == "credits_500":
        player["credits"] += 500
    elif purchase.item_id == "credits_1000":
        player["credits"] += 1000
    elif purchase.item_id == "premium_ship":
        player["upgrades"]["premium"] = True
        player["damage"] += 10
        player["maxHealth"] += 50
    
    save_data(data)
    
    return {
        "success": True,
        "message": "Покупка успешна",
        "item": purchase.item_id,
        "credits": player["credits"]
    }

@app.delete("/api/player/{telegram_id}")
async def delete_player(telegram_id: int):
    """Delete player data (GDPR compliance)"""
    data = load_data()
    
    player_key = str(telegram_id)
    if player_key in data["players"]:
        del data["players"][player_key]
        
        # Remove from leaderboard
        data["leaderboard"] = [
            entry for entry in data["leaderboard"]
            if entry["telegram_id"] != telegram_id
        ]
        
        save_data(data)
        
        return {
            "success": True,
            "message": "Данные игрока удалены"
        }
    
    raise HTTPException(status_code=404, detail="Игрок не найден")

@app.get("/api/stats")
async def get_stats():
    """Get global game statistics"""
    data = load_data()
    
    total_players = len(data["players"])
    total_score = sum(p["score"] for p in data["players"].values())
    total_kills = sum(p["kills"] for p in data["players"].values())
    total_purchases = len(data["purchases"])
    
    avg_level = sum(p["level"] for p in data["players"].values()) / max(total_players, 1)
    
    return {
        "success": True,
        "stats": {
            "total_players": total_players,
            "total_score": total_score,
            "total_kills": total_kills,
            "total_purchases": total_purchases,
            "average_level": round(avg_level, 2),
            "highest_score": max([p["score"] for p in data["players"].values()], default=0),
            "highest_level": max([p["level"] for p in data["players"].values()], default=0)
        }
    }

# ================================
# HELPER FUNCTIONS
# ================================

def update_leaderboard(data, stats: PlayerStats):
    """Update leaderboard with player stats"""
    # Remove existing entry
    data["leaderboard"] = [
        entry for entry in data["leaderboard"]
        if entry["telegram_id"] != stats.telegram_id
    ]
    
    # Add new entry
    data["leaderboard"].append({
        "telegram_id": stats.telegram_id,
        "username": stats.username,
        "score": stats.score,
        "level": stats.level,
        "kills": stats.kills
    })

# ================================
# MONETIZATION ENDPOINTS
# ================================

@app.get("/api/shop/items")
async def get_shop_items():
    """Get available shop items for purchase"""
    return {
        "success": True,
        "items": [
            {
                "id": "credits_100",
                "name": "100 Кредитов",
                "price": 50,  # Telegram Stars
                "description": "Пакет из 100 игровых кредитов"
            },
            {
                "id": "credits_500",
                "name": "500 Кредитов",
                "price": 200,
                "description": "Пакет из 500 игровых кредитов",
                "discount": "20%"
            },
            {
                "id": "credits_1000",
                "name": "1000 Кредитов",
                "price": 350,
                "description": "Пакет из 1000 игровых кредитов",
                "discount": "30%"
            },
            {
                "id": "premium_ship",
                "name": "Премиум Корабль",
                "price": 500,
                "description": "Эксклюзивный корабль с бонусами: +10 урон, +50 HP"
            },
            {
                "id": "energy_boost",
                "name": "Энергетический Бустер",
                "price": 100,
                "description": "Бесконечная энергия на 24 часа"
            },
            {
                "id": "double_exp",
                "name": "Двойной Опыт",
                "price": 150,
                "description": "x2 опыт на 24 часа"
            }
        ]
    }

@app.post("/api/achievement/unlock")
async def unlock_achievement(telegram_id: int, achievement_id: str):
    """Unlock achievement for player"""
    data = load_data()
    
    player_key = str(telegram_id)
    if player_key not in data["players"]:
        raise HTTPException(status_code=404, detail="Игрок не найден")
    
    player = data["players"][player_key]
    
    if "achievements" not in player:
        player["achievements"] = []
    
    if achievement_id not in player["achievements"]:
        player["achievements"].append(achievement_id)
        save_data(data)
        
        return {
            "success": True,
            "message": "Достижение разблокировано",
            "achievement": achievement_id
        }
    
    return {
        "success": False,
        "message": "Достижение уже разблокировано"
    }

# ================================
# ADMIN ENDPOINTS
# ================================

@app.get("/api/admin/backup")
async def backup_data(admin_key: str = ""):
    """Create backup of game data"""
    if admin_key != "space_odyssey_admin_2025":
        raise HTTPException(status_code=403, detail="Доступ запрещен")
    
    data = load_data()
    backup_file = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    
    with open(backup_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    return {
        "success": True,
        "message": "Backup создан",
        "file": backup_file
    }

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Space Odyssey Backend Server...")
    print("📡 API будет доступен на http://localhost:8000")
    print("📚 Документация API: http://localhost:8000/docs")
    uvicorn.run(app, host="0.0.0.0", port=8000)
