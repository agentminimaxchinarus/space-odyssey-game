/**
 * Advanced Game Features Module
 * Дополнительные игровые механики для расширения Space Odyssey
 */

// ================================
// DAILY REWARDS SYSTEM
// ================================

class DailyRewardsSystem {
    constructor() {
        this.lastClaim = this.getLastClaim();
        this.streak = this.getStreak();
        this.rewards = [
            { day: 1, credits: 100, description: "100 Кредитов" },
            { day: 2, credits: 150, description: "150 Кредитов" },
            { day: 3, credits: 200, energy: 50, description: "200 Кредитов + 50 Энергии" },
            { day: 4, credits: 300, description: "300 Кредитов" },
            { day: 5, credits: 500, special: "weapon_boost", description: "500 Кредитов + Усиление оружия" },
            { day: 6, credits: 750, description: "750 Кредитов" },
            { day: 7, credits: 1000, special: "premium_day", description: "1000 Кредитов + Премиум на день" }
        ];
    }
    
    getLastClaim() {
        const lastClaim = localStorage.getItem('lastDailyReward');
        return lastClaim ? parseInt(lastClaim) : 0;
    }
    
    getStreak() {
        const streak = localStorage.getItem('dailyStreak');
        return streak ? parseInt(streak) : 0;
    }
    
    canClaim() {
        const now = Date.now();
        const dayInMs = 24 * 60 * 60 * 1000;
        return now - this.lastClaim >= dayInMs;
    }
    
    claimReward() {
        if (!this.canClaim()) {
            return { success: false, message: "Награда уже получена сегодня" };
        }
        
        const now = Date.now();
        const daysSinceLastClaim = Math.floor((now - this.lastClaim) / (24 * 60 * 60 * 1000));
        
        // Check if streak is broken
        if (daysSinceLastClaim > 1) {
            this.streak = 1;
        } else {
            this.streak = (this.streak % 7) + 1;
        }
        
        const reward = this.rewards[this.streak - 1];
        
        // Apply rewards
        GameState.player.credits += reward.credits;
        if (reward.energy) {
            GameState.player.energy += reward.energy;
        }
        if (reward.special === 'weapon_boost') {
            GameState.player.damage += 5;
        }
        if (reward.special === 'premium_day') {
            GameState.player.premiumUntil = Date.now() + (24 * 60 * 60 * 1000);
        }
        
        this.lastClaim = now;
        localStorage.setItem('lastDailyReward', now.toString());
        localStorage.setItem('dailyStreak', this.streak.toString());
        
        updateUI();
        
        return {
            success: true,
            reward: reward,
            streak: this.streak
        };
    }
    
    showDailyRewardModal() {
        const canClaim = this.canClaim();
        const nextReward = this.rewards[this.streak % 7];
        
        const modalHTML = `
            <div class="daily-reward-container">
                <h2>🎁 Ежедневная Награда</h2>
                <div class="streak-info">
                    <p>Серия: ${this.streak} ${this.streak === 7 ? '🏆' : ''}</p>
                </div>
                <div class="reward-calendar">
                    ${this.rewards.map((r, i) => `
                        <div class="reward-day ${i < this.streak ? 'claimed' : ''} ${i === this.streak && canClaim ? 'available' : ''}">
                            <div class="day-number">День ${r.day}</div>
                            <div class="day-reward">${r.description}</div>
                        </div>
                    `).join('')}
                </div>
                ${canClaim ? 
                    `<button class="claim-btn" onclick="claimDailyReward()">Получить награду!</button>` :
                    `<p class="next-claim">Следующая награда через: ${this.getTimeUntilNext()}</p>`
                }
            </div>
        `;
        
        showModal(modalHTML);
    }
    
    getTimeUntilNext() {
        const now = Date.now();
        const nextClaim = this.lastClaim + (24 * 60 * 60 * 1000);
        const diff = nextClaim - now;
        
        const hours = Math.floor(diff / (60 * 60 * 1000));
        const minutes = Math.floor((diff % (60 * 60 * 1000)) / (60 * 1000));
        
        return `${hours}ч ${minutes}м`;
    }
}

// ================================
// ACHIEVEMENT SYSTEM
// ================================

class AchievementSystem {
    constructor() {
        this.achievements = [
            {
                id: 'first_kill',
                name: 'Первая кровь',
                description: 'Уничтожь первого врага',
                reward: 100,
                icon: '🎯',
                check: () => GameState.player.kills >= 1
            },
            {
                id: 'kill_10',
                name: 'Охотник',
                description: 'Уничтожь 10 врагов',
                reward: 250,
                icon: '🔫',
                check: () => GameState.player.kills >= 10
            },
            {
                id: 'kill_50',
                name: 'Убийца',
                description: 'Уничтожь 50 врагов',
                reward: 500,
                icon: '💀',
                check: () => GameState.player.kills >= 50
            },
            {
                id: 'kill_100',
                name: 'Легенда',
                description: 'Уничтожь 100 врагов',
                reward: 1000,
                icon: '👑',
                check: () => GameState.player.kills >= 100
            },
            {
                id: 'level_5',
                name: 'Новичок',
                description: 'Достигни 5 уровня',
                reward: 300,
                icon: '⬆️',
                check: () => GameState.player.level >= 5
            },
            {
                id: 'level_10',
                name: 'Эксперт',
                description: 'Достигни 10 уровня',
                reward: 750,
                icon: '🌟',
                check: () => GameState.player.level >= 10
            },
            {
                id: 'rich',
                name: 'Богач',
                description: 'Накопи 5000 кредитов',
                reward: 500,
                icon: '💰',
                check: () => GameState.player.credits >= 5000
            },
            {
                id: 'survivor',
                name: 'Выживший',
                description: 'Продержись 10 минут',
                reward: 600,
                icon: '⏱️',
                check: () => GameState.playTime >= 600000
            },
            {
                id: 'boss_killer',
                name: 'Убийца боссов',
                description: 'Победи босса',
                reward: 1500,
                icon: '👹',
                check: () => GameState.player.bossKills >= 1
            },
            {
                id: 'no_damage',
                name: 'Неуязвимый',
                description: 'Пройди волну без урона',
                reward: 800,
                icon: '🛡️',
                check: () => GameState.player.perfectWaves >= 1
            }
        ];
        
        this.unlocked = this.loadUnlocked();
    }
    
    loadUnlocked() {
        const unlocked = localStorage.getItem('achievementsUnlocked');
        return unlocked ? JSON.parse(unlocked) : [];
    }
    
    saveUnlocked() {
        localStorage.setItem('achievementsUnlocked', JSON.stringify(this.unlocked));
    }
    
    check() {
        this.achievements.forEach(achievement => {
            if (!this.unlocked.includes(achievement.id) && achievement.check()) {
                this.unlock(achievement);
            }
        });
    }
    
    unlock(achievement) {
        this.unlocked.push(achievement.id);
        this.saveUnlocked();
        
        // Give reward
        GameState.player.credits += achievement.reward;
        updateUI();
        
        // Show notification
        this.showAchievementNotification(achievement);
        
        // Haptic feedback
        if (telegramIntegration?.isAvailable) {
            telegramIntegration.hapticNotification('success');
        }
    }
    
    showAchievementNotification(achievement) {
        const notification = document.createElement('div');
        notification.className = 'achievement-notification';
        notification.innerHTML = `
            <div class="achievement-icon">${achievement.icon}</div>
            <div class="achievement-content">
                <div class="achievement-title">Достижение разблокировано!</div>
                <div class="achievement-name">${achievement.name}</div>
                <div class="achievement-reward">+${achievement.reward} кредитов</div>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 500);
        }, 4000);
    }
    
    getProgress() {
        return {
            total: this.achievements.length,
            unlocked: this.unlocked.length,
            percentage: Math.floor((this.unlocked.length / this.achievements.length) * 100)
        };
    }
}

// ================================
// BATTLE PASS SYSTEM
// ================================

class BattlePassSystem {
    constructor() {
        this.season = 1;
        this.xp = this.loadXP();
        this.level = this.calculateLevel();
        this.isPremium = this.checkPremium();
        
        this.rewards = this.generateRewards();
    }
    
    loadXP() {
        const xp = localStorage.getItem('battlePassXP');
        return xp ? parseInt(xp) : 0;
    }
    
    saveXP() {
        localStorage.setItem('battlePassXP', this.xp.toString());
    }
    
    checkPremium() {
        const premium = localStorage.getItem('battlePassPremium');
        return premium === 'true';
    }
    
    calculateLevel() {
        return Math.floor(this.xp / 1000) + 1;
    }
    
    addXP(amount) {
        this.xp += amount;
        const newLevel = this.calculateLevel();
        
        if (newLevel > this.level) {
            this.onLevelUp(newLevel);
        }
        
        this.level = newLevel;
        this.saveXP();
    }
    
    onLevelUp(newLevel) {
        const rewards = this.rewards[newLevel - 1];
        
        if (rewards) {
            // Give free reward
            this.giveReward(rewards.free);
            
            // Give premium reward if has premium
            if (this.isPremium && rewards.premium) {
                this.giveReward(rewards.premium);
            }
            
            this.showLevelUpNotification(newLevel, rewards);
        }
    }
    
    giveReward(reward) {
        if (reward.type === 'credits') {
            GameState.player.credits += reward.amount;
        } else if (reward.type === 'upgrade') {
            // Apply specific upgrade
            applyUpgrade(reward.upgrade);
        }
        
        updateUI();
    }
    
    generateRewards() {
        const rewards = [];
        for (let i = 1; i <= 50; i++) {
            rewards.push({
                free: {
                    type: 'credits',
                    amount: i * 100
                },
                premium: {
                    type: i % 5 === 0 ? 'upgrade' : 'credits',
                    amount: i * 200,
                    upgrade: i % 5 === 0 ? 'random' : null
                }
            });
        }
        return rewards;
    }
    
    purchasePremium() {
        // This would trigger Telegram Stars payment
        if (telegramIntegration?.isAvailable) {
            telegramIntegration.openInvoice({
                id: 'battle_pass_premium',
                name: 'Battle Pass Premium',
                description: 'Разблокируй премиум награды на весь сезон',
                price: 1000 // Stars
            });
        }
    }
    
    showLevelUpNotification(level, rewards) {
        alert(`Battle Pass Уровень ${level}!\n\nПолучено:\n${rewards.free.amount} кредитов${this.isPremium ? `\n+ ${rewards.premium.amount} кредитов (Premium)` : ''}`);
    }
}

// ================================
// PVP ARENA SYSTEM (Async)
// ================================

class PVPArenaSystem {
    constructor() {
        this.ranking = 1000; // ELO rating
        this.wins = 0;
        this.losses = 0;
        this.isSearching = false;
    }
    
    async findMatch() {
        this.isSearching = true;
        
        // Simulate matchmaking
        return new Promise((resolve) => {
            setTimeout(() => {
                // In real implementation, this would call backend API
                const opponent = this.generateOpponent();
                this.isSearching = false;
                resolve(opponent);
            }, 3000);
        });
    }
    
    generateOpponent() {
        const rankingDiff = Math.floor(Math.random() * 200) - 100;
        const opponentRanking = this.ranking + rankingDiff;
        
        return {
            username: `Player_${Math.floor(Math.random() * 9999)}`,
            ranking: opponentRanking,
            level: Math.floor(opponentRanking / 100),
            ship: Math.random() > 0.5 ? 'premium' : 'basic'
        };
    }
    
    async startBattle(opponent) {
        // Start PVP battle mode
        showPVPBattle(opponent);
    }
    
    recordResult(won, opponentRanking) {
        const K = 32; // ELO K-factor
        const expectedScore = 1 / (1 + Math.pow(10, (opponentRanking - this.ranking) / 400));
        const actualScore = won ? 1 : 0;
        
        const ratingChange = Math.floor(K * (actualScore - expectedScore));
        this.ranking += ratingChange;
        
        if (won) {
            this.wins++;
            GameState.player.credits += 200;
        } else {
            this.losses++;
        }
        
        this.saveStats();
        
        return {
            ratingChange: ratingChange,
            newRanking: this.ranking
        };
    }
    
    saveStats() {
        localStorage.setItem('pvpRanking', this.ranking.toString());
        localStorage.setItem('pvpWins', this.wins.toString());
        localStorage.setItem('pvpLosses', this.losses.toString());
    }
}

// ================================
// CLAN SYSTEM
// ================================

class ClanSystem {
    constructor() {
        this.clanId = this.getClanId();
        this.clanData = null;
    }
    
    getClanId() {
        return localStorage.getItem('clanId');
    }
    
    async createClan(name, tag) {
        // Call backend API to create clan
        const response = await fetch('/api/clan/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: name,
                tag: tag,
                founder_id: telegramIntegration?.userId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            this.clanId = data.clan_id;
            localStorage.setItem('clanId', this.clanId);
            return { success: true, clan: data.clan };
        }
        
        return { success: false, error: data.error };
    }
    
    async joinClan(clanId) {
        // Call backend API to join clan
        const response = await fetch('/api/clan/join', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                clan_id: clanId,
                user_id: telegramIntegration?.userId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            this.clanId = clanId;
            localStorage.setItem('clanId', clanId);
            return { success: true };
        }
        
        return { success: false, error: data.error };
    }
    
    async leaveClan() {
        if (!this.clanId) return;
        
        // Call backend API
        await fetch('/api/clan/leave', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                clan_id: this.clanId,
                user_id: telegramIntegration?.userId
            })
        });
        
        this.clanId = null;
        localStorage.removeItem('clanId');
    }
    
    async getClanInfo() {
        if (!this.clanId) return null;
        
        const response = await fetch(`/api/clan/${this.clanId}`);
        const data = await response.json();
        
        if (data.success) {
            this.clanData = data.clan;
            return this.clanData;
        }
        
        return null;
    }
}

// ================================
// INITIALIZE SYSTEMS
// ================================

let dailyRewards, achievements, battlePass, pvpArena, clanSystem;

function initAdvancedSystems() {
    dailyRewards = new DailyRewardsSystem();
    achievements = new AchievementSystem();
    battlePass = new BattlePassSystem();
    pvpArena = new PVPArenaSystem();
    clanSystem = new ClanSystem();
    
    // Check achievements periodically
    setInterval(() => {
        if (GameState.isRunning && !GameState.isPaused) {
            achievements.check();
        }
    }, 5000);
    
    console.log('✅ Advanced systems initialized');
}

// Auto-initialize on load
window.addEventListener('load', () => {
    setTimeout(initAdvancedSystems, 1000);
});

// Export for global access
window.GameSystems = {
    dailyRewards,
    achievements,
    battlePass,
    pvpArena,
    clanSystem
};
