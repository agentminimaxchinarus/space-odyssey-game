# Space Odyssey - 3D Space RPG для Telegram Mini Apps

## 🎮 Описание

Полноценная 3D космическая RPG игра для Telegram Mini Apps с:
- **Современная 3D графика** на Three.js
- **Система прокачки** персонажа и корабля
- **Квестовая система** с наградами
- **Монетизация** через Telegram Stars
- **Лидерборды** и достижения
- **Backend на Python** для сохранения прогресса

## 🚀 Быстрый старт

### Вариант 1: Только Frontend (без сохранений)

Просто откройте `index.html` в браузере или разместите на хостинге:

```bash
# Локально
python -m http.server 8080
# Затем откройте http://localhost:8080
```

### Вариант 2: С Backend (полная версия)

1. **Установите зависимости:**
```bash
pip install -r requirements.txt
```

2. **Запустите сервер:**
```bash
python server.py
```

3. **Откройте игру:**
```bash
# В другом терминале
python -m http.server 8080
```

## 📁 Структура проекта

```
space-odyssey/
├── index.html          # Главная страница игры
├── game.js            # Игровой движок (Three.js)
├── server.py          # Backend API (FastAPI)
├── requirements.txt   # Python зависимости
├── game_data.json     # База данных (создается автоматически)
└── README.md          # Эта документация
```

## 🎯 Игровые возможности

### Основной геймплей
- **Управление кораблем** через виртуальный джойстик
- **Система боя** с различными типами врагов
- **Прокачка** оружия, щитов, двигателей
- **Боссы** каждые 5 волн
- **Power-ups** для восстановления здоровья и энергии

### Враги
1. **Basic** - базовый враг (HP: 30)
2. **Fast** - быстрый враг (HP: 20)
3. **Tank** - танк (HP: 60)
4. **Boss** - босс (HP: 300)

### Система улучшений
- 🔫 **Оружие** - увеличение урона (+5)
- 🛡️ **Щит** - увеличение защиты (+2)
- 🚀 **Двигатель** - увеличение скорости (+20%)
- ⚡ **Энергия** - увеличение макс. энергии (+20)
- 💫 **Спец. атака** - уменьшение перезарядки (-20%)
- ❤️ **Здоровье** - увеличение HP (+30)

### Миссии
1. Первый контакт - Уничтожь 10 врагов (500 кредитов)
2. Коллекционер - Собери 1000 кредитов (1000 кредитов)
3. Выживший - Достигни 5 уровня (2000 кредитов)
4. Охотник на боссов - Победи первого босса (3000 кредитов)
5. Мастер космоса - Набери 10000 очков (5000 кредитов)

## 💰 Монетизация (Telegram Stars)

### Доступные покупки:
- **100 Кредитов** - 50 Stars
- **500 Кредитов** - 200 Stars (скидка 20%)
- **1000 Кредитов** - 350 Stars (скидка 30%)
- **Премиум Корабль** - 500 Stars (+10 урон, +50 HP)
- **Энергетический Бустер** - 100 Stars (бесконечная энергия 24ч)
- **Двойной Опыт** - 150 Stars (x2 опыт 24ч)

## 🔧 API Документация

### Endpoints

#### Сохранение прогресса
```http
POST /api/player/save
Content-Type: application/json

{
  "telegram_id": 123456789,
  "username": "player_name",
  "level": 5,
  "score": 5000,
  "credits": 1000,
  ...
}
```

#### Получение прогресса
```http
GET /api/player/{telegram_id}
```

#### Лидерборд
```http
GET /api/leaderboard?limit=100
GET /api/leaderboard/level
GET /api/leaderboard/kills
```

#### Покупки
```http
POST /api/purchase
Content-Type: application/json

{
  "telegram_id": 123456789,
  "item_id": "credits_500",
  "amount": 1
}
```

#### Статистика
```http
GET /api/stats
```

## 🌐 Интеграция с Telegram

### Настройка Telegram Bot

1. Создайте бота через [@BotFather](https://t.me/BotFather)
2. Получите токен бота
3. Создайте Web App через BotFather:
   ```
   /newapp
   Выберите вашего бота
   Введите название: Space Odyssey
   Введите описание: 3D космическая RPG игра
   Загрузите иконку (512x512)
   Введите URL: https://your-domain.com
   ```

### Конфигурация в коде

В `game.js` уже подключена интеграция:
```javascript
let tg = window.Telegram?.WebApp;
if (tg) {
    tg.ready();
    tg.expand();
}
```

## 🎨 Кастомизация

### Изменение сложности
В `game.js`, найдите `GameState.settings`:
```javascript
settings: {
    difficulty: 1,          // Множитель сложности
    waveNumber: 1,          // Стартовая волна
    enemiesPerWave: 5,      // Врагов на волну
    bossEvery: 5           // Босс каждые N волн
}
```

### Изменение характеристик игрока
```javascript
player: {
    health: 100,
    maxHealth: 100,
    damage: 10,
    fireRate: 250,  // мс между выстрелами
    speed: 0.5,     // скорость движения
    ...
}
```

## 📱 Адаптация под платформы

### Telegram Mini Apps
- ✅ Полная поддержка
- ✅ Haptic feedback
- ✅ Telegram Stars интеграция
- ✅ Адаптивный UI

### Веб-браузер
- ✅ Desktop (мышь)
- ✅ Mobile (тач)
- ✅ Полноэкранный режим

## 🔒 Безопасность

### Backend
- Проверка Telegram InitData для авторизации
- Rate limiting на API endpoints
- Валидация всех входных данных
- CORS настроен корректно

### Frontend
- No XSS vulnerabilities
- CSP headers рекомендуется
- Secure WebSocket connections

## 📊 Производительность

### Оптимизация
- Object pooling для bullets/particles
- Frustum culling включен
- LOD (Level of Detail) для дальних объектов
- Ограничение FPS для mobile

### Рекомендуемые настройки
- **Desktop**: 60 FPS
- **Mobile**: 30-60 FPS
- **Max enemies**: 15 одновременно
- **Max particles**: 200

## 🚀 Деплой

### Vercel
```bash
npm i -g vercel
vercel
```

### Netlify
```bash
npm i -g netlify-cli
netlify deploy
```

### Собственный сервер
```bash
# Frontend
nginx + static files

# Backend
gunicorn server:app -w 4 -k uvicorn.workers.UvicornWorker
```

### Docker
```bash
docker build -t space-odyssey .
docker run -p 8000:8000 space-odyssey
```

## 🐛 Отладка

### Включить debug режим
В `game.js`:
```javascript
const DEBUG = true;

if (DEBUG) {
    console.log('Player position:', player.position);
    console.log('Enemies:', enemies.length);
}
```

### Проверка производительности
```javascript
// В gameLoop()
const stats = renderer.info;
console.log('Triangles:', stats.render.triangles);
console.log('Calls:', stats.render.calls);
```

## 📝 Лицензия

Этот проект создан для демонстрации возможностей Telegram Mini Apps.
Вы можете свободно использовать и модифицировать код.

## 🤝 Поддержка

Если у вас есть вопросы или предложения:
- Создайте Issue на GitHub
- Напишите в Telegram: @your_support_bot

## 🎉 Благодарности

- Three.js за отличный 3D движок
- Telegram за платформу Mini Apps
- FastAPI за быстрый backend framework

---

**Версия:** 1.0.0  
**Дата:** 2025  
**Автор:** MiniMax Agent

Приятной игры! 🚀✨
