from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import json
import os
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = FastAPI(title="Space Odyssey API", version="1.0.0")

# CORS configuration for Vercel
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For production, specify your domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuration
DATA_FILE = "game_data.json"

class PlayerStats(BaseModel):
    telegram_id: int
    username: str
    level: int
    score: int
    credits: int
    kills: int
    health: int
    maxHealth: int
    energy: int
    maxEnergy: int
    exp: int
    expToLevel: int
    damage: int
    defense: int
    upgrades: dict
    missions_completed: List[int] = []
    last_played: str

def load_data():
    """Load game data from JSON file"""
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading data: {e}")
    return {
        "players": {},
        "leaderboard": [],
        "purchases": []
    }

def save_data(data):
    """Save game data to JSON file"""
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Error saving data: {e}")
        return False

@app.get("/")
async def root():
    """API health check"""
    return {
        "status": "online",
        "game": "Space Odyssey",
        "version": "1.0.0",
        "message": "Space Odyssey API is running!"
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "service": "space-odyssey-backend"
    }

@app.post("/api/player/save")
async def save_player(stats: PlayerStats):
    """Save player progress"""
    data = load_data()
    
    try:
        stats.last_played = datetime.now().isoformat()
        data["players"][str(stats.telegram_id)] = stats.dict()
        
        # Update leaderboard
        update_leaderboard(data, stats)
        
        if save_data(data):
            return {
                "success": True,
                "message": "Прогресс сохранен",
                "timestamp": stats.last_played
            }
        else:
            return {
                "success": False,
                "message": "Ошибка сохранения"
            }
    except Exception as e:
        return {
            "success": False,
            "message": f"Ошибка: {str(e)}"
        }

@app.get("/api/player/{telegram_id}")
async def get_player(telegram_id: int):
    """Get player progress"""
    data = load_data()
    
    player_key = str(telegram_id)
    if player_key in data["players"]:
        return {
            "success": True,
            "data": data["players"][player_key]
        }
    
    return {
        "success": False,
        "message": "Игрок не найден"
    }

@app.get("/api/leaderboard")
async def get_leaderboard(limit: int = 100):
    """Get top players leaderboard"""
    data = load_data()
    
    leaderboard = sorted(
        data["leaderboard"],
        key=lambda x: x["score"],
        reverse=True
    )[:limit]
    
    return {
        "success": True,
        "leaderboard": leaderboard,
        "total_players": len(data["players"])
    }

@app.get("/api/shop/items")
async def get_shop_items():
    """Get available shop items for purchase"""
    return {
        "success": True,
        "items": [
            {
                "id": "credits_100",
                "name": "100 Кредитов",
                "price": 50,
                "description": "Пакет из 100 игровых кредитов"
            },
            {
                "id": "credits_500", 
                "name": "500 Кредитов",
                "price": 200,
                "description": "Пакет из 500 игровых кредитов",
                "discount": "20%"
            },
            {
                "id": "credits_1000",
                "name": "1000 Кредитов", 
                "price": 350,
                "description": "Пакет из 1000 игровых кредитов",
                "discount": "30%"
            },
            {
                "id": "premium_ship",
                "name": "Премиум Корабль",
                "price": 500,
                "description": "Эксклюзивный корабль с бонусами: +10 урон, +50 HP"
            },
            {
                "id": "energy_boost",
                "name": "Энергетический Бустер",
                "price": 100,
                "description": "Бесконечная энергия на 24 часа"
            },
            {
                "id": "double_exp",
                "name": "Двойной Опыт",
                "price": 150,
                "description": "x2 опыт на 24 часа"
            }
        ]
    }

def update_leaderboard(data, stats: PlayerStats):
    """Update leaderboard with player stats"""
    # Remove existing entry
    data["leaderboard"] = [
        entry for entry in data["leaderboard"]
        if entry["telegram_id"] != stats.telegram_id
    ]
    
    # Add new entry
    data["leaderboard"].append({
        "telegram_id": stats.telegram_id,
        "username": stats.username,
        "score": stats.score,
        "level": stats.level,
        "kills": stats.kills
    })