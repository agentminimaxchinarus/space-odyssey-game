# Telegram Bot Configuration для Space Odyssey
# Используйте эту информацию для настройки вашего бота

## Ваш Bot Token
**8495213971:AAFr97f8dUSeE43cNSj22PAX5PnKnLU6tRY**

## Шаги настройки:

### 1. Web App Configuration
После развертывания файлов на хостинге (получите URL типа https://yourapp.vercel.app):

1. Откройте @BotFather в Telegram
2. Отправьте `/newapp`
3. Выберите вашего бота
4. Введите URL вашего приложения (например: `https://yourapp.vercel.app`)
5. Добавьте описание: "3D Space RPG Game - Полноценная космическая RPG"
6. Укажите иконки: используйте изображение 512x512px

### 2. Bot Menu Button
1. В @BotFather отправьте `/setmenubutton`
2. Выберите вашего бота
3. Введите текст: "🚀 Играть в Space Odyssey"
4. Добавьте URL кнопки: `https://yourapp.vercel.app`

### 3. Game Configuration
1. В @BotFather отправьте `/newgame`
2. Выберите вашего бота
3. Введите название игры: "Space Odyssey"
4. Введите описание: "3D космическая RPG с монетизацией через Telegram Stars"
5. Добавьте URL: `https://yourapp.vercel.app`

## Проверочные команды:
- `/start` - запускает бота
- `/newapp` - создает web app
- `/newgame` - создает игру
- `/setmenubutton` - настраивает меню бота

## Monetization Setup:
Для включения платежей через Telegram Stars:
1. Убедитесь, что бот проверен (@BotFather)
2. Настройте Web App с HTTPS URL
3. Тестируйте платежи в режиме разработки

## Тестирование:
После настройки:
1. Найдите вашего бота в Telegram
2. Нажмите на кнопку "🚀 Играть в Space Odyssey"
3. Проверьте, что игра загружается
4. Протестируйте сохранение прогресса
5. Проверьте покупки через Telegram Stars

## Безопасность:
- Никогда не публикуйте BOT_TOKEN в открытом коде
- Используйте переменные окружения для production
- Регулярно обновляйте токен если необходимо

## Поддержка:
- API документация: /docs
- Статус сервера: /
- Логи смотрите в консоли браузера и сервера