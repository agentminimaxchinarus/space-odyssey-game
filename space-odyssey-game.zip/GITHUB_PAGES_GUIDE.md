# 🚀 Развертывание на GitHub Pages

## Шаг 1: Создание репозитория

1. **Зайдите на [GitHub.com](https://github.com)**
2. **Нажмите "New Repository"** (зеленая кнопка "New")
3. **Заполните поля:**
   - Repository name: `space-odyssey-game`
   - Description: `3D Space RPG Game for Telegram Mini Apps`
   - Выберите **Public** (GitHub Pages работает только с публичными репозиториями для бесплатного тарифа)
   - ✅ Отметьте "Add a README file"
   - ✅ Отметьте "Add .gitignore" (выберите "Node")
4. **Нажмите "Create repository"**

## Шаг 2: Загрузка файлов

### Вариант A: Через веб-интерфейс GitHub (Рекомендуется)

1. **Откройте созданный репозиторий**
2. **Нажмите "uploading an existing file"** (или "Upload files")
3. **Загрузите все файлы из проекта:**
   - `index.html`
   - `game.js`
   - `telegram-integration.js`
   - `advanced-features.js`
   - `package.json`
   - `requirements.txt`
   - `vercel.json` (переименуйте в `gh-pages.json`)
   - `server.py` (или `vercel-api.py`)
   - `.env`
   - Все остальные файлы из проекта

4. **Commit changes** - нажмите "Commit changes"

### Вариант B: Через Git (для продвинутых)

```bash
# Клонируйте репозиторий
git clone https://github.com/YOUR_USERNAME/space-odyssey-game.git
cd space-odyssey-game

# Скопируйте все файлы проекта в папку репозитория
# ...

# Зафиксируйте изменения
git add .
git commit -m "Initial commit: Space Odyssey RPG Game"
git push
```

## Шаг 3: Настройка GitHub Pages

1. **В репозитории зайдите в Settings**
2. **Прокрутите вниз до раздела "Pages"**
3. **В разделе "Source" выберите:**
   - **Deploy from a branch**
   - **Branch: main**
   - **Folder: / (root)**
4. **Нажмите "Save"**
5. **GitHub покажет сообщение:**
   ```
   "Your site is ready to be published at https://YOUR_USERNAME.github.io/space-odyssey-game/"
   ```

## Шаг 4: Получение URL для бота

**После развертывания (1-2 минуты) ваш сайт будет доступен по адресу:**
```
https://YOUR_USERNAME.github.io/space-odyssey-game/
```

**Этот URL нужно будет добавить в @BotFather**

## Шаг 5: Настройка Telegram бота

1. **Откройте [@BotFather](https://t.me/BotFather)**
2. **Отправьте `/newapp`**
3. **Выберите вашего бота** (если еще не создан, то сначала `/newbot`)
4. **Введите данные:**
   - **Name:** Space Odyssey
   - **Description:** 3D космическая RPG игра с монетизацией
   - **Photo:** загрузите иконку 512x512px
   - **URL:** `https://YOUR_USERNAME.github.io/space-odyssey-game/`
5. **Нажмите "Send"**

## Шаг 6: Настройка меню бота

1. **В @BotFather отправьте `/setmenubutton`**
2. **Выберите вашего бота**
3. **Введите текст кнопки:** `🚀 Играть в Space Odyssey`
4. **Введите URL:** `https://YOUR_USERNAME.github.io/space-odyssey-game/`

## Шаг 7: Создание игры (опционально)

1. **В @BotFather отправьте `/newgame`**
2. **Выберите вашего бота**
3. **Введите название игры:** Space Odyssey
4. **Введите описание:** "3D космическая RPG с монетизацией через Telegram Stars"
5. **Добавьте URL:** `https://YOUR_USERNAME.github.io/space-odyssey-game/`

## ✅ Проверка развертывания

### Локальная проверка:
1. **Откройте** `https://YOUR_USERNAME.github.io/space-odyssey-game/`
2. **Проверьте, что игра загружается**
3. **Проверьте консоль браузера** (F12) - не должно быть ошибок

### Telegram проверка:
1. **Найдите вашего бота в Telegram**
2. **Нажмите кнопку "🚀 Играть в Space Odyssey"**
3. **Проверьте, что игра открывается в мини-приложении**
4. **Протестируйте основной функционал**

## 🔧 Дополнительная настройка

### Пользовательский домен (опционально):
1. **В Settings → Pages → Custom domain**
2. **Введите ваш домен** (например, `game.example.com`)
3. **Создайте CNAME запись в DNS:**
   ```
   game.example.com → YOUR_USERNAME.github.io
   ```
4. **Настройте HTTPS** (GitHub Pages автоматически настроит Let's Encrypt)

### Обновление игры:
- Просто загрузите новые файлы в репозиторий
- GitHub Pages автоматически обновит сайт (1-2 минуты)
- Никаких дополнительных настроек не требуется

## 📊 Преимущества GitHub Pages

✅ **Бесплатно** - неограниченные запросы для публичных репозиториев
✅ **HTTPS автоматически** - безопасные подключения
✅ **Пользовательские домены** - можно использовать собственный домен
✅ **Простое обновление** - загрузил файл = сайт обновлен
✅ **Надежность** - 99.9% uptime от GitHub
✅ **CDN** - быстрая загрузка по всему миру
✅ **Интеграция с Git** - версионирование изменений

## 🚀 ГОТОВО!

После завершения всех шагов:
1. **Ваша игра будет доступна по адресу** `https://YOUR_USERNAME.github.io/space-odyssey-game/`
2. **Бот будет работать с кнопкой "🚀 Играть в Space Odyssey"**
3. **Telegram мини-приложение будет открывать игру**
4. **Все готово к монетизации через Telegram Stars!**

## 🔍 Troubleshooting

**Сайт не загружается?**
- Подождите 2-5 минут после настройки Pages
- Проверьте Settings → Pages → Source
- Убедитесь, что файл `index.html` находится в корне репозитория

**Кнопка бота не работает?**
- Убедитесь, что URL в @BotFather точно совпадает с адресом сайта
- Проверьте, что сайт доступен и загружается в браузере
- Попробуйте пересоздать Web App в @BotFather

**Ошибки в консоли игры?**
- Проверьте, что все JS файлы загружены в репозиторий
- Убедитесь, что в файлах нет относительных путей
- Проверьте кодировку файлов (UTF-8)