#!/bin/bash

# Space Odyssey - Быстрый запуск с настроенным ботом
echo "🚀 Space Odyssey - Запуск с настроенным Telegram ботом"
echo "=================================================="

# Проверяем Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 не найден. Установите Python 3.8+"
    exit 1
fi

# Проверяем pip
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 не найден. Установите pip3"
    exit 1
fi

echo "✅ Python найден"

# Устанавливаем зависимости
echo "📦 Устанавливаем зависимости..."
pip3 install -r requirements.txt
pip3 install python-dotenv

if [ $? -eq 0 ]; then
    echo "✅ Зависимости установлены"
else
    echo "❌ Ошибка установки зависимостей"
    exit 1
fi

# Проверяем настройки бота
if grep -q "8495213971:AAFr97f8dUSeE43cNSj22PAX5PnKnLU6tRY" .env; then
    echo "✅ Telegram Bot токен настроен"
else
    echo "⚠️  Создаем файл конфигурации..."
    cat > .env << EOL
TELEGRAM_BOT_TOKEN=8495213971:AAFr97f8dUSeE43cNSj22PAX5PnKnLU6tRY
API_HOST=0.0.0.0
API_PORT=8000
DATA_FILE=game_data.json
ADMIN_KEY=space_odyssey_admin_2025
GAME_NAME=Space Odyssey
GAME_VERSION=1.0.0
ENVIRONMENT=production
EOL
fi

# Запускаем backend
echo "🖥️  Запускаем backend сервер..."
echo "📡 API будет доступен на: http://localhost:8000"
echo "📚 Документация: http://localhost:8000/docs"
echo ""
echo "🌐 Frontend (игра) - откройте файл index.html в браузере"
echo ""
echo "⚡ НАЖМИТЕ Ctrl+C для остановки сервера"
echo ""

# Запускаем сервер
python3 server.py